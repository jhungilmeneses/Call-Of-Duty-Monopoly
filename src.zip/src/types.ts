export type SpaceType = 'property' | 'corner' | 'chance' | 'community' | 'tax' | 'railroad' | 'utility';

export interface SpaceData {
  id: number;
  name: string;
  type: SpaceType;
  price?: number;
  color?: string;
  icon?: string;
  subtitle?: string;
}

export interface Player {
  id: number;
  name: string;
  position: number;
  money: number;
  color: string;
  tokenUrl?: string;
  isEliminated?: boolean;
  powStatus?: 'free' | 'captured_needs_choice' | 'captured_waiting';
  waitTurns?: number;
  hasGetOutOfPowCard?: boolean;
  hasUsedNuke?: boolean;
  isNPC?: boolean;
}

export interface PropertyOwnership {
  ownerId: number;
  level: 'tent' | 'hq';
  isMortgaged?: boolean;
}

export interface TradeOffer {
  id: string;
  senderId: number;
  receiverId: number;
  offeredMoney: number;
  requestedMoney: number;
  offeredProperties: number[];
  requestedProperties: number[];
  senderConfirmed: boolean;
  receiverConfirmed: boolean;
  status: 'pending' | 'cancelled' | 'declined' | 'completed';
}
