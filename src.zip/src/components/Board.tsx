import React from 'react';
import { spaces } from '../data/board';
import Space from './Space';
import { Player, SpaceData, PropertyOwnership } from '../types';
import * as Icons from 'lucide-react';

interface BoardProps {
  players: Player[];
  properties: Record<number, PropertyOwnership>;
  onSpaceClick: (space: SpaceData) => void;
  onDeckClick?: (deck: 'chest' | 'chance') => void;
  pendingCardDraw?: 'chest' | 'chance' | null;
  visualEffect?: 'nuke' | 'missile' | null;
  effectTarget?: number | null;
}

const Board: React.FC<BoardProps> = ({ players, properties, onSpaceClick, onDeckClick, pendingCardDraw, visualEffect, effectTarget }) => {
  // 11x11 grid
  const topRow = spaces.slice(20, 31);
  const rightRow = spaces.slice(31, 40);
  const bottomRow = spaces.slice(0, 11).reverse();
  const leftRow = spaces.slice(11, 20).reverse();

  return (
    <div className="relative w-full max-w-5xl aspect-square bg-[#cde6d0] border-2 border-black grid grid-cols-[1.4fr_1fr_1fr_1fr_1fr_1fr_1fr_1fr_1fr_1fr_1.4fr] grid-rows-[1.4fr_1fr_1fr_1fr_1fr_1fr_1fr_1fr_1fr_1fr_1.4fr] gap-0 p-2 shadow-2xl">
      {/* Center Logo and Decks */}
      <div className="col-start-2 col-end-11 row-start-2 row-end-11 flex items-center justify-center bg-[#728c69] m-2 border-2 border-black/20 relative overflow-hidden">
        
        {/* Top Secret Files Deck */}
        <div 
          onClick={() => onDeckClick && onDeckClick('chest')}
          className={`absolute top-10 left-10 transform -rotate-45 w-40 h-28 bg-[#cde6d0] border-2 border-black rounded-sm flex flex-col items-center justify-center shadow-[4px_4px_0_rgba(0,0,0,1)] transition-all text-black ${pendingCardDraw === 'chest' ? 'cursor-pointer hover:-translate-y-1 hover:shadow-[6px_6px_0_rgba(0,0,0,1)] ring-4 ring-yellow-400 animate-pulse' : 'opacity-80'}`}
        >
           <Icons.FolderLock className="w-8 h-8 mb-2" />
           <span className="font-bold text-base text-center leading-tight">Top Secret<br/>Files</span>
        </div>

        {/* Radio Deck */}
        <div 
          onClick={() => onDeckClick && onDeckClick('chance')}
          className={`absolute bottom-10 right-10 transform -rotate-45 w-40 h-28 bg-[#cde6d0] border-2 border-black rounded-sm flex flex-col items-center justify-center shadow-[4px_4px_0_rgba(0,0,0,1)] transition-all text-black ${pendingCardDraw === 'chance' ? 'cursor-pointer hover:-translate-y-1 hover:shadow-[6px_6px_0_rgba(0,0,0,1)] ring-4 ring-yellow-400 animate-pulse' : 'opacity-80'}`}
        >
           <Icons.Radio className="w-8 h-8 mb-2" />
           <span className="font-bold text-base">Radio</span>
        </div>

        <div className="transform -rotate-45 text-7xl font-black tracking-tighter text-black/90 flex items-center gap-3">
          <span>CALL</span>
          <span className="text-4xl">OF</span>
          <span>DUTY</span>
        </div>
      </div>

      {/* Top Row (20 to 30) */}
      {topRow.map((space, i) => (
        <div key={space.id} className="col-span-1 row-span-1" style={{ gridColumnStart: i + 1, gridRowStart: 1 }}>
          <Space data={space} players={players.filter(p => p.position === space.id && !p.isEliminated)} properties={properties} orientation="top" onClick={() => onSpaceClick(space)} visualEffect={visualEffect} effectTarget={effectTarget} />
        </div>
      ))}

      {/* Right Row (31 to 39) */}
      {rightRow.map((space, i) => (
        <div key={space.id} className="col-span-1 row-span-1" style={{ gridColumnStart: 11, gridRowStart: i + 2 }}>
          <Space data={space} players={players.filter(p => p.position === space.id && !p.isEliminated)} properties={properties} orientation="right" onClick={() => onSpaceClick(space)} visualEffect={visualEffect} effectTarget={effectTarget} />
        </div>
      ))}

      {/* Bottom Row (10 to 0) */}
      {bottomRow.map((space, i) => (
        <div key={space.id} className="col-span-1 row-span-1" style={{ gridColumnStart: i + 1, gridRowStart: 11 }}>
          <Space data={space} players={players.filter(p => p.position === space.id && !p.isEliminated)} properties={properties} orientation="bottom" onClick={() => onSpaceClick(space)} visualEffect={visualEffect} effectTarget={effectTarget} />
        </div>
      ))}

      {/* Left Row (19 down to 11) */}
      {leftRow.map((space, i) => (
        <div key={space.id} className="col-span-1 row-span-1" style={{ gridColumnStart: 1, gridRowStart: i + 2 }}>
          <Space data={space} players={players.filter(p => p.position === space.id && !p.isEliminated)} properties={properties} orientation="left" onClick={() => onSpaceClick(space)} visualEffect={visualEffect} effectTarget={effectTarget} />
        </div>
      ))}
    </div>
  );
};

export default Board;
