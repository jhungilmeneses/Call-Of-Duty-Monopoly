import React from 'react';

interface NumericalKeypadProps {
  value: number;
  onChange: (value: number) => void;
  max: number;
  onClose: () => void;
}

export const NumericalKeypad: React.FC<NumericalKeypadProps> = ({ value, onChange, max, onClose }) => {
  const handlePress = (num: number) => {
    const newValue = value * 10 + num;
    if (newValue <= max) {
      onChange(newValue);
    } else {
      onChange(max);
    }
  };

  const handleBackspace = () => {
    onChange(Math.floor(value / 10));
  };

  const handleClear = () => {
    onChange(0);
  };

  return (
    <div className="fixed inset-0 bg-black/80 z-[60] flex items-center justify-center p-4 backdrop-blur-sm" onClick={onClose}>
      <div className="bg-neutral-800 p-6 rounded-xl border border-neutral-700 max-w-xs w-full shadow-2xl" onClick={e => e.stopPropagation()}>
        <div className="text-right text-3xl font-mono bg-neutral-900 p-4 rounded-lg mb-4 border border-neutral-700 text-white">
          ${value}
        </div>
        <div className="grid grid-cols-3 gap-2">
          {[1, 2, 3, 4, 5, 6, 7, 8, 9].map(num => (
            <button
              key={num}
              onClick={() => handlePress(num)}
              className="bg-neutral-700 hover:bg-neutral-600 text-white text-2xl py-4 rounded-lg font-bold transition-colors active:scale-95"
            >
              {num}
            </button>
          ))}
          <button
            onClick={handleClear}
            className="bg-red-900/50 hover:bg-red-800/50 text-red-400 text-xl py-4 rounded-lg font-bold transition-colors active:scale-95"
          >
            CLR
          </button>
          <button
            onClick={() => handlePress(0)}
            className="bg-neutral-700 hover:bg-neutral-600 text-white text-2xl py-4 rounded-lg font-bold transition-colors active:scale-95"
          >
            0
          </button>
          <button
            onClick={handleBackspace}
            className="bg-neutral-700 hover:bg-neutral-600 text-white text-xl py-4 rounded-lg font-bold transition-colors active:scale-95 flex items-center justify-center"
          >
            ⌫
          </button>
        </div>
        <button
          onClick={onClose}
          className="w-full mt-4 py-3 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-lg transition-colors active:scale-95"
        >
          Done
        </button>
      </div>
    </div>
  );
};
