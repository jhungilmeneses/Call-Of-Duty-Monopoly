import React from 'react';
import { SpaceData, Player, PropertyOwnership } from '../types';
import * as Icons from 'lucide-react';

interface SpaceProps {
  data: SpaceData;
  players: Player[];
  properties?: Record<number, PropertyOwnership>;
  orientation: 'top' | 'right' | 'bottom' | 'left';
  onClick?: () => void;
  visualEffect?: 'nuke' | 'missile' | null;
  effectTarget?: number | null;
}

const Space: React.FC<SpaceProps> = ({ data, players, properties, orientation, onClick, visualEffect, effectTarget }) => {
  const isCorner = data.type === 'corner';
  
  let rotationClass = '';
  if (!isCorner) {
    if (orientation === 'top') rotationClass = 'rotate-180';
    if (orientation === 'right') rotationClass = '-rotate-90';
    if (orientation === 'left') rotationClass = 'rotate-90';
  } else {
    if (data.id === 20) rotationClass = 'rotate-[135deg]'; // Top Left
    if (data.id === 30) rotationClass = '-rotate-[135deg]'; // Top Right
    if (data.id === 10) rotationClass = 'rotate-[45deg]'; // Bottom Left
    if (data.id === 0) rotationClass = '-rotate-[45deg]'; // Bottom Right
  }

  const IconComponent = data.icon ? (Icons as any)[data.icon] : null;
  const isLeftOrRight = (orientation === 'left' || orientation === 'right') && !isCorner;

  return (
    <div 
      className={`w-full h-full relative cursor-pointer hover:brightness-95 transition-all subpixel-antialiased`}
      style={{ textRendering: 'geometricPrecision' }}
      onClick={onClick}
    >
      <div className="absolute inset-0 border border-black bg-[#cde6d0] overflow-hidden">
        {data.id === 10 ? (
          <div className="absolute inset-0 flex flex-col bg-[#cde6d0]">
            <div className="flex-1 flex h-[70%]">
              {/* Left bar */}
              <div className="w-[30%] flex items-center justify-center border-r-2 border-black">
                <span className="transform -rotate-90 font-black text-[8px] tracking-widest uppercase whitespace-nowrap text-black">Visiting</span>
              </div>
              {/* Top Right Square */}
              <div className="w-[70%] bg-[#f7941d] flex items-center justify-center border-b-2 border-black overflow-hidden relative">
                <div className="transform rotate-[45deg] flex flex-col items-center justify-center w-[140%] h-[140%]">
                  <span className="font-black text-[9px] leading-tight uppercase text-center text-black">POW<br/>CAMP</span>
                  <Icons.Fence className="w-6 h-6 mt-0.5 opacity-90 text-black" strokeWidth={2.5} />
                </div>
                {/* Captured Players */}
                {players.filter(p => p.powStatus === 'captured_needs_choice' || p.powStatus === 'captured_waiting').length > 0 && (
                  <div className="absolute inset-0 flex flex-wrap items-center justify-center gap-1 pointer-events-none z-10 bg-black/20">
                    {players.filter(p => p.powStatus === 'captured_needs_choice' || p.powStatus === 'captured_waiting').map(p => (
                      <div key={p.id} className="relative group">
                        {visualEffect === 'missile' && effectTarget === p.id && (
                          <div className="absolute -inset-4 bg-orange-500 rounded-full blur-md animate-ping z-50 flex items-center justify-center">
                            <span className="text-xl">💥</span>
                          </div>
                        )}
                        {p.tokenUrl ? (
                          <img src={p.tokenUrl} alt={p.name} className="w-5 h-5 object-contain drop-shadow-md" title={p.name} />
                        ) : (
                          <div className={`w-3 h-3 rounded-full border border-white shadow-sm ${p.color}`} title={p.name} />
                        )}
                        <div className="absolute -top-2 -right-2 bg-black text-white text-[6px] font-bold px-0.5 rounded shadow-sm border border-white/50 z-20">
                          P{p.id}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
            {/* Bottom bar */}
            <div className="h-[30%] flex items-center justify-center relative">
              <span className="font-black text-[8px] tracking-widest uppercase text-black">Space</span>
            </div>
            {/* Visiting Players */}
            {players.filter(p => p.powStatus !== 'captured_needs_choice' && p.powStatus !== 'captured_waiting').length > 0 && (
              <div className="absolute bottom-1 left-1 w-[80%] h-[80%] flex flex-wrap items-end justify-start gap-1 pointer-events-none z-10">
                {players.filter(p => p.powStatus !== 'captured_needs_choice' && p.powStatus !== 'captured_waiting').map(p => (
                  <div key={p.id} className="relative group">
                    {visualEffect === 'missile' && effectTarget === p.id && (
                      <div className="absolute -inset-4 bg-orange-500 rounded-full blur-md animate-ping z-50 flex items-center justify-center">
                        <span className="text-xl">💥</span>
                      </div>
                    )}
                    {p.tokenUrl ? (
                      <img src={p.tokenUrl} alt={p.name} className="w-5 h-5 object-contain drop-shadow-md" title={p.name} />
                    ) : (
                      <div className={`w-3 h-3 rounded-full border border-white shadow-sm ${p.color}`} title={p.name} />
                    )}
                    <div className="absolute -top-2 -right-2 bg-black text-white text-[6px] font-bold px-0.5 rounded shadow-sm border border-white/50 z-20">
                      P{p.id}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        ) : (
          <div 
            className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 flex flex-col ${rotationClass}`}
            style={{
              width: isLeftOrRight ? 'calc(100% / 1.4)' : '100%',
              height: isLeftOrRight ? 'calc(100% * 1.4)' : '100%',
            }}
          >
            {data.type === 'property' && (
              <div className={`h-[25%] min-h-[16px] shrink-0 w-full border-b-2 border-black ${data.color}`} />
            )}
            
            <div className={`flex-1 flex flex-col items-center justify-between p-1 text-center text-black ${isCorner ? 'justify-center gap-1' : ''}`}>
              <span className={`font-black uppercase tracking-tight break-words w-full px-0.5 ${isCorner ? 'text-[11px] leading-tight' : 'text-[7.5px] leading-[1.1] mt-0.5'}`}>
                {data.name}
              </span>
              
              {IconComponent && (
                <IconComponent className={`${isCorner ? 'w-7 h-7' : 'w-4 h-4'} my-auto opacity-90`} strokeWidth={2.5} />
              )}
              
              {data.subtitle && (
                <span className="text-[6.5px] leading-none font-extrabold uppercase tracking-tight">{data.subtitle}</span>
              )}

              {data.price && (
                <span className="text-[7.5px] leading-none font-extrabold mb-0.5">${data.price}</span>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Players (for non-POW CAMP tiles) */}
      {data.id !== 10 && players.length > 0 && (
        <div className="absolute inset-0 flex flex-wrap items-center justify-center gap-1 pointer-events-none bg-black/10 z-20">
          {players.map(p => (
            <div key={p.id} className="relative group">
              {visualEffect === 'missile' && effectTarget === p.id && (
                <div className="absolute -inset-4 bg-orange-500 rounded-full blur-md animate-ping z-50 flex items-center justify-center">
                  <span className="text-xl">💥</span>
                </div>
              )}
              {p.tokenUrl ? (
                <img 
                  src={p.tokenUrl}
                  alt={p.name}
                  className="w-5 h-5 object-contain drop-shadow-md"
                  title={p.name}
                />
              ) : (
                <div 
                  className={`w-3 h-3 rounded-full border border-white shadow-sm ${p.color}`}
                  title={p.name}
                />
              )}
              <div className="absolute -top-2 -right-2 bg-black text-white text-[6px] font-bold px-0.5 rounded shadow-sm border border-white/50 z-20">
                P{p.id}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Property Ownership Indicator */}
      {properties && properties[data.id] && (
        <div className={`absolute top-1 left-1 pointer-events-none z-30 drop-shadow-md ${properties[data.id].isMortgaged ? 'opacity-50 grayscale' : ''}`}>
          {['Supply Depot', 'Ammunition', 'Advance UAV', 'Support Helo', 'Military Convoy', 'Gunship'].includes(data.name) ? (
            <div className="bg-black text-white text-[10px] font-bold px-1.5 py-0.5 rounded shadow-sm border border-white/50 z-40">
              P{properties[data.id].ownerId}
            </div>
          ) : (
            <>
              <img 
                src={`/COD PROPERTY ICONS/${properties[data.id].level === 'hq' ? 'HQ' : 'Tent'}.png`} 
                alt={properties[data.id].level} 
                className="w-6 h-6 object-contain"
              />
              <div className="absolute -top-1 -right-1 bg-black text-white text-[6px] font-bold px-0.5 rounded shadow-sm border border-white/50 z-40">
                P{properties[data.id].ownerId}
              </div>
            </>
          )}
          {properties[data.id].isMortgaged && (
            <div className="absolute -bottom-2 -right-2 bg-red-600 text-white text-[6px] font-bold px-0.5 rounded shadow-sm border border-white/50 z-40">
              M
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default Space;
