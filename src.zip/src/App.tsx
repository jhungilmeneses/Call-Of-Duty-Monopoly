import React, { useState, useEffect } from 'react';
import Board from './components/Board';
import { Player, SpaceData, PropertyOwnership, TradeOffer } from './types';
import { Dice5, X, Clock, MapPin } from 'lucide-react';
import { spaces } from './data/board';
import { NumericalKeypad } from './components/NumericalKeypad';
import { auth, db } from './firebase';
import { signInWithEmailAndPassword, createUserWithEmailAndPassword } from 'firebase/auth';
import { ref, set, onValue, get, update, remove, onDisconnect } from 'firebase/database';

const initialPlayers: Player[] = [
  { id: 1, name: 'Ghost', position: 0, money: 1500, color: 'bg-red-500', tokenUrl: '/COD AVATARS/Ghost.png', powStatus: 'free', waitTurns: 0, isEliminated: false },
  { id: 2, name: 'Price', position: 0, money: 1500, color: 'bg-blue-500', tokenUrl: '/COD AVATARS/Price.png', powStatus: 'free', waitTurns: 0, isEliminated: false },
  { id: 3, name: 'Soap', position: 0, money: 1500, color: 'bg-green-500', tokenUrl: '/COD AVATARS/Soap.png', powStatus: 'free', waitTurns: 0, isEliminated: false },
  { id: 4, name: 'Gaz', position: 0, money: 1500, color: 'bg-yellow-500', tokenUrl: '/COD AVATARS/Gaz.png', powStatus: 'free', waitTurns: 0, isEliminated: false },
];

export default function App() {
  const [players, setPlayers] = useState<Player[]>(initialPlayers);
  const [currentPlayerIndex, setCurrentPlayerIndex] = useState(0);
  const [dice, setDice] = useState<[number, number]>([1, 1]);
  const [selectedSpace, setSelectedSpace] = useState<SpaceData | null>(null);
  const [pendingCardDraw, setPendingCardDraw] = useState<'chest' | 'chance' | null>(null);
  const [drawnCard, setDrawnCard] = useState<{type: 'chest' | 'chance', id: number} | null>(null);
  const [showPlayerSelect, setShowPlayerSelect] = useState<boolean>(false);
  const [selectedTargetPlayer, setSelectedTargetPlayer] = useState<number | null>(null);
  const [properties, setProperties] = useState<Record<number, PropertyOwnership>>({});
  const [timeLeft, setTimeLeft] = useState(120);
  const [hasRolled, setHasRolled] = useState(false);
  const [hasActed, setHasActed] = useState(false);
  const [mustPayRent, setMustPayRent] = useState(false);
  const [showTradeModal, setShowTradeModal] = useState(false);
  const [showCapturePointModal, setShowCapturePointModal] = useState(false);
  const [capturableProperties, setCapturableProperties] = useState<number[]>([]);
  const [activeTrades, setActiveTrades] = useState<TradeOffer[]>([]);
  const [tradeState, setTradeState] = useState<{
    targetPlayerId: number;
    offeredMoney: number;
    requestedMoney: number;
    offeredProperties: number[];
    requestedProperties: number[];
  }>({
    targetPlayerId: 2,
    offeredMoney: 0,
    requestedMoney: 0,
    offeredProperties: [],
    requestedProperties: []
  });
  const [activeKeypad, setActiveKeypad] = useState<'player1' | 'player2' | null>(null);
  const [musicEnabled, setMusicEnabled] = useState(true);
  const [musicVolume, setMusicVolume] = useState(0.5);
  const [sfxEnabled, setSfxEnabled] = useState(true);
  const [sfxVolume, setSfxVolume] = useState(0.5);
  const [visualEffect, setVisualEffect] = useState<'nuke' | 'missile' | null>(null);
  const [effectTarget, setEffectTarget] = useState<number | null>(null);
  const [gameOver, setGameOver] = useState(false);
  const [twoPlayerAnnouncementMade, setTwoPlayerAnnouncementMade] = useState(false);
  const [restartVotes, setRestartVotes] = useState<number[]>([]);
  const [restartTimer, setRestartTimer] = useState(20);
  const [eliminatedPlayerAlert, setEliminatedPlayerAlert] = useState<Player | null>(null);
  const [bgMusic] = useState(() => new Audio('/COD MUSIC AND SFX/Conflict Desert Storm 2 Mobeus Theme.mp3'));
  
  // Menu & Settings State
  const [currentView, setCurrentView] = useState<'login' | 'main_menu' | 'lobby' | 'game'>('login');
  const [gameMode, setGameMode] = useState<'singleplayer' | 'multiplayer'>('multiplayer');
  const [loginUsername, setLoginUsername] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [isPaused, setIsPaused] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showMultiplayerModal, setShowMultiplayerModal] = useState(false);
  const [showOnlineOptions, setShowOnlineOptions] = useState(false);
  const [joinLobbyInput, setJoinLobbyInput] = useState('');
  const [lobbyCode, setLobbyCode] = useState('');
  const [lobbyPlayers, setLobbyPlayers] = useState<{id: number, name: string, isHost: boolean}[]>([]);
  const [localUserId, setLocalUserId] = useState(1); // Simulate local user ID
  const [turnDuration, setTurnDuration] = useState(120);
  const [brightness, setBrightness] = useState(1);
  const [isFullscreen, setIsFullscreen] = useState(false);

  useEffect(() => {
    bgMusic.loop = true;
    bgMusic.volume = musicEnabled ? musicVolume : 0;
    // Play on first interaction to avoid autoplay issues
    const playMusic = () => {
      bgMusic.play().catch(e => console.log("Audio play failed:", e));
      playAudio('/COD MUSIC AND SFX/Mission Start and Mission End  Sound Effect.mp3');
      document.removeEventListener('click', playMusic);
    };
    document.addEventListener('click', playMusic);
    return () => {
      document.removeEventListener('click', playMusic);
      bgMusic.pause();
    };
  }, []);

  useEffect(() => {
    bgMusic.volume = musicEnabled ? musicVolume : 0;
  }, [musicVolume, musicEnabled, bgMusic]);

  const isSyncingFromNetwork = React.useRef(false);

  // Centralized Firebase Matchmaking & Game State Listener
  useEffect(() => {
    if (!lobbyCode) return;

    // Listen for players dropping or joining
    const playersUnsub = onValue(ref(db, `lobbies/${lobbyCode}/players`), (snapshot) => {
      const playersData = snapshot.val();
      if (playersData) {
        const pList = Object.values(playersData) as any[];
        setLobbyPlayers(pList);
        
        // Kicked check
        const amIKicked = !pList.find(p => p.id === localUserId);
        if (amIKicked && currentView !== 'main_menu') {
           alert("You have been kicked by the host.");
           setLobbyCode('');
           setCurrentView('main_menu');
        }
      }
    });

    const statusUnsub = onValue(ref(db, `lobbies/${lobbyCode}/status`), (snapshot) => {
      if (snapshot.val() === 'playing' && currentView !== 'game') {
        get(ref(db, `lobbies/${lobbyCode}/gamePlayers`)).then(snap => {
          if (snap.val()) {
            startNewGame('multiplayer', snap.val());
            setCurrentView('game');
          }
        });
      }
    });

    const gameUpdateUnsub = onValue(ref(db, `lobbies/${lobbyCode}/state`), (snapshot) => {
      const state = snapshot.val();
      if (state) {
        isSyncingFromNetwork.current = true;
        if (state.players) setPlayers(state.players);
        if (state.currentPlayerIndex !== undefined) setCurrentPlayerIndex(state.currentPlayerIndex);
        if (state.dice) setDice(state.dice);
        if (state.properties !== undefined) setProperties(state.properties); else setProperties({});
        if (state.timeLeft !== undefined) setTimeLeft(state.timeLeft);
        if (state.hasRolled !== undefined) setHasRolled(state.hasRolled);
        if (state.mustPayRent !== undefined) setMustPayRent(state.mustPayRent);
        if (state.drawnCard !== undefined) setDrawnCard(state.drawnCard); else setDrawnCard(null);
        if (state.pendingCardDraw !== undefined) setPendingCardDraw(state.pendingCardDraw); else setPendingCardDraw(null);
        if (state.showPlayerSelect !== undefined) setShowPlayerSelect(state.showPlayerSelect);
        if (state.gameOver !== undefined) setGameOver(state.gameOver);
        
        if (state.activeTrades !== undefined) {
          setActiveTrades(state.activeTrades.map((t: any) => ({
            ...t,
            offeredProperties: t.offeredProperties || [],
            requestedProperties: t.requestedProperties || []
          })));
        } else {
          setActiveTrades([]);
        }
        if (state.turnDuration !== undefined) setTurnDuration(state.turnDuration);
        
        setTimeout(() => {
          isSyncingFromNetwork.current = false;
        }, 50);
      }
    });

    return () => {
      playersUnsub();
      statusUnsub();
      gameUpdateUnsub();
    };
  }, [lobbyCode, localUserId, currentView]);

  // Broadcast local actions to the Firebase network
  useEffect(() => {
    if (gameMode === 'multiplayer' && lobbyCode && currentView === 'game' && !isSyncingFromNetwork.current) {
      set(ref(db, `lobbies/${lobbyCode}/state`), {
        players,
        currentPlayerIndex,
        dice,
        properties,
        timeLeft,
        hasRolled,
        mustPayRent,
        drawnCard,
        pendingCardDraw,
        showPlayerSelect,
        gameOver,
        activeTrades,
        turnDuration
      });
    }
  }, [players, currentPlayerIndex, dice, properties, hasRolled, mustPayRent, drawnCard, pendingCardDraw, showPlayerSelect, gameOver, activeTrades, turnDuration, lobbyCode, currentView, gameMode]);

  const syncGameState = (updates: any = {}) => {
    // Legacy helper - mostly handled by the useEffect above now
  };

  const playAudio = (src: string) => {
    const audio = new Audio(src);
    audio.volume = sfxEnabled ? sfxVolume : 0;
    if (sfxEnabled) {
      audio.play().catch(e => console.log("Audio play failed:", e));
    }
    return audio;
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const startNewGame = (mode: 'singleplayer' | 'multiplayer' = 'multiplayer', customPlayers?: Player[]) => {
    setGameMode(mode);
    setPlayers(customPlayers || initialPlayers);
    setCurrentPlayerIndex(0);
    setDice([1, 1]);
    setSelectedSpace(null);
    setPendingCardDraw(null);
    setDrawnCard(null);
    setShowPlayerSelect(false);
    setSelectedTargetPlayer(null);
    setProperties({});
    setTimeLeft(turnDuration);
    setHasRolled(false);
    setHasActed(false);
    setMustPayRent(false);
    setShowTradeModal(false);
    setShowCapturePointModal(false);
    setCapturableProperties([]);
    setTradeState({
      targetPlayerId: 2,
      offeredMoney: 0,
      requestedMoney: 0,
      offeredProperties: [],
      requestedProperties: []
    });
    setActiveKeypad(null);
    setVisualEffect(null);
    setEffectTarget(null);
    setGameOver(false);
    setTwoPlayerAnnouncementMade(false);
    setRestartVotes([]);
    setRestartTimer(20);
    setIsPaused(false);
    setCurrentView('game');
    playAudio('/COD MUSIC AND SFX/Mission Start and Mission End  Sound Effect.mp3');
  };



  useEffect(() => {
    const activePlayers = players.filter(p => !p.isEliminated);
    
    if (activePlayers.length === 2 && !twoPlayerAnnouncementMade && currentView === 'game') {
      setTwoPlayerAnnouncementMade(true);
      playAudio("/COD MUSIC AND SFX/Voicy_You're the last one complete the mission.mp3");
    }
    
    if (activePlayers.length <= 1 && !gameOver && currentView === 'game') {
      setGameOver(true);
      const winAudio = playAudio('/COD MUSIC AND SFX/Mission Accomplished, Good Work (Call of Duty_ MW2).mp3');
      winAudio.onended = () => {
        playAudio('/COD MUSIC AND SFX/Voicy_The Call Me The CODfather.mp3');
      };
      playAudio('/COD MUSIC AND SFX/Mission Failed we\'ll get em next time Sound Effect.mp3');
    }
  }, [players, twoPlayerAnnouncementMade, gameOver, currentView]);

  useEffect(() => {
    if (!gameOver || currentView === 'main_menu' || currentView === 'login' || currentView === 'lobby') return;

    // Auto-vote for NPCs in singleplayer
    if (gameMode === 'singleplayer') {
      setRestartVotes(prev => {
        const newVotes = [...prev];
        let changed = false;
        players.forEach(p => {
          if (p.id !== players[0].id && !newVotes.includes(p.id)) {
            newVotes.push(p.id);
            changed = true;
          }
        });
        return changed ? newVotes : prev;
      });
    }

    if (restartVotes.length === players.length) {
      // Restart game
      setPlayers(initialPlayers);
      setCurrentPlayerIndex(0);
      setProperties({});
      setGameOver(false);
      setTwoPlayerAnnouncementMade(false);
      setRestartVotes([]);
      setRestartTimer(20);
      playAudio('/COD MUSIC AND SFX/Mission Start and Mission End  Sound Effect.mp3');
      return;
    }

    const timer = setInterval(() => {
      setRestartTimer(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          // Return to main menu if not everyone agreed
          setCurrentView('main_menu');
          setGameOver(false);
          setRestartVotes([]);
          return 20;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [gameOver, restartVotes, players.length, currentView]);

  useEffect(() => {
    if (players.filter(p => !p.isEliminated).length <= 1) return;
    if (isPaused || currentView === 'main_menu' || currentView === 'login' || currentView === 'lobby') return;
    
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          endTurn(currentPlayerIndex);
          return turnDuration;
        }
        return prev - 1;
      });
    }, 1000);
    
    return () => clearInterval(timer);
  }, [currentPlayerIndex, players, isPaused, turnDuration]);

  const currentPlayer = players[currentPlayerIndex];

  const endTurn = (currentIndex: number) => {
    setTimeLeft(turnDuration);
    setHasRolled(false);
    setHasActed(false);
    setPlayers(prevPlayers => {
      const newPlayers = prevPlayers.map(p => ({...p}));
      let nextIdx = (currentIndex + 1) % newPlayers.length;
      let loopCount = 0;

      while (loopCount < newPlayers.length) {
        const p = newPlayers[nextIdx];
        if (p.isEliminated) {
          nextIdx = (nextIdx + 1) % newPlayers.length;
          loopCount++;
          continue;
        }
        if (p.powStatus === 'captured_waiting') {
          if (p.waitTurns && p.waitTurns > 1) {
            p.waitTurns--;
            nextIdx = (nextIdx + 1) % newPlayers.length;
            loopCount++;
            continue;
          } else if (p.waitTurns === 1) {
            p.waitTurns = 0;
            nextIdx = (nextIdx + 1) % newPlayers.length;
            loopCount++;
            continue;
          } else {
            p.powStatus = 'free';
            break;
          }
        } else if (p.waitTurns && p.waitTurns > 0) {
          p.waitTurns--;
          nextIdx = (nextIdx + 1) % newPlayers.length;
          loopCount++;
          continue;
        }
        break;
      }
      
      if (loopCount >= newPlayers.length) {
        // Everyone is eliminated
        return newPlayers;
      }
      
      setCurrentPlayerIndex(nextIdx);
      return newPlayers;
    });
  };

  const previousLobbyIds = React.useRef<string>('');
  useEffect(() => {
    if (gameMode !== 'multiplayer' || currentView !== 'game') return;

    const currentIds = lobbyPlayers.map(p => p.id).sort().join(',');
    if (previousLobbyIds.current === '') {
      previousLobbyIds.current = currentIds;
      return;
    }
    
    if (currentIds === previousLobbyIds.current) return;
    
    // Evaluate missing IDs
    const currentActiveIds = lobbyPlayers.map(p => p.id);
    const disconnectedIds = players.filter(p => !p.isNPC && !currentActiveIds.includes(p.id)).map(p => p.id);
    
    // Always track mutations for potential host migrations
    previousLobbyIds.current = currentIds;

    // Only actual current host dictates global game state cleanup sync logic
    const amIHost = lobbyPlayers.find(p => p.id === localUserId)?.isHost;
    if (!amIHost) return;

    if (disconnectedIds.length > 0) {
      console.log('Players disconnected, cleaning up data...', disconnectedIds);

      // Return properties to bank
      setProperties(prev => {
        const newProps = { ...prev };
        Object.keys(newProps).forEach(spaceId => {
          if (disconnectedIds.includes(newProps[Number(spaceId)].ownerId)) {
            delete newProps[Number(spaceId)];
          }
        });
        return newProps;
      });

      // Clear all active trades relating to the deleted players
      setActiveTrades(prev => prev.filter(t => !disconnectedIds.includes(t.senderId) && !disconnectedIds.includes(t.receiverId)));

      // Eliminate the players from players list (mark as Eliminated to keep them visible but powerless)
      setPlayers(prev => {
        const cPlayer = prev[currentPlayerIndex];
        const newPlayersList = prev.map(p => 
          disconnectedIds.includes(p.id) ? { ...p, isEliminated: true, money: 0 } : p
        );
        
        if (cPlayer && disconnectedIds.includes(cPlayer.id)) {
           // Automatically fast-forward turn to the next alive participant
           let nextIndex = currentPlayerIndex;
           do {
             nextIndex = (nextIndex + 1) % newPlayersList.length;
           } while (newPlayersList[nextIndex].isEliminated && nextIndex !== currentPlayerIndex);
           setCurrentPlayerIndex(nextIndex);
        }
        
        return newPlayersList;
      });
    }
  }, [lobbyPlayers, players, currentPlayerIndex, gameMode, currentView, localUserId]);

  const handleTradeResponse = (tradeId: string, action: 'accept' | 'decline' | 'cancel') => {
    const trade = activeTrades.find(t => t.id === tradeId);
    if (!trade) return;

    if (action === 'cancel' && trade.senderId !== localUserId) return;
    if (action === 'accept' || action === 'decline') {
      const p = players.find(p => p.id === trade.receiverId);
      const isNPCPlayer = p?.isNPC;
      // Allow NPCs to respond via the host process
      if (!isNPCPlayer && trade.receiverId !== localUserId) return;
      if (isNPCPlayer && gameMode === 'multiplayer' && !(lobbyPlayers?.find(p => p.id === localUserId)?.isHost)) return;
    }

    if (action === 'accept') {
      const sIdx = players.findIndex(p => p.id === trade.senderId);
      const rIdx = players.findIndex(p => p.id === trade.receiverId);
      if (sIdx === -1 || rIdx === -1) return;

      if (players[sIdx].money < trade.offeredMoney || players[rIdx].money < trade.requestedMoney) {
         if (!players.find(p => p.id === trade.receiverId)?.isNPC) {
             alert("Insufficient funds to complete trade.");
         }
         return;
      }
      
      setPlayers(prev => {
        const np = [...prev].map(p => ({...p}));
        np[sIdx].money = np[sIdx].money - trade.offeredMoney + trade.requestedMoney;
        np[rIdx].money = np[rIdx].money - trade.requestedMoney + trade.offeredMoney;
        return np;
      });

      setProperties(prev => {
        const np = {...prev};
        trade.offeredProperties.forEach(id => {
          if (np[id]) np[id].ownerId = trade.receiverId;
        });
        trade.requestedProperties.forEach(id => {
          if (np[id]) np[id].ownerId = trade.senderId;
        });
        return np;
      });
      
      if (gameMode === 'multiplayer' && localUserId === trade.receiverId) {
          alert('Trade accepted and executed successfully!');
      }
    }
    
    setActiveTrades(prev => prev.filter(t => t.id !== tradeId));
  };

  const rollDice = () => {
    playAudio('/COD MUSIC AND SFX/Dice Rolls.mp3');
    const d1 = Math.floor(Math.random() * 6) + 1;
    const d2 = Math.floor(Math.random() * 6) + 1;
    setDice([d1, d2]);
    
    const total = d1 + d2;
    let rolledDoubles = d1 === d2;
    let endedInPow = false;
    let newPos = (currentPlayer.position + total) % 40;
    if (newPos === 30) {
      newPos = 10;
      endedInPow = true;
    }
    
    setPlayers(prev => {
      const newPlayers = prev.map(p => ({...p}));
      const player = newPlayers[currentPlayerIndex];
      
      const oldPosition = player.position;
      player.position = newPos;
      
      // Pass GO
      if (player.position < oldPosition && player.position !== 10) {
        player.money += 200;
      }

      // POW CAPTURED
      if (endedInPow) {
        player.powStatus = 'captured_needs_choice';
      }
      
      setSelectedSpace(spaces[player.position]);
      return newPlayers;
    });

    if (properties[newPos] && properties[newPos].ownerId !== currentPlayer.id && !properties[newPos].isMortgaged) {
      setMustPayRent(true);
    }

    if (newPos === 4 || newPos === 38) {
      // Capture the Point
      const otherPlayerProperties = Object.entries(properties)
        .filter(([_, prop]) => prop.ownerId !== currentPlayer.id)
        .map(([id]) => Number(id));
      
      if (otherPlayerProperties.length > 0) {
        setCapturableProperties(otherPlayerProperties);
        setShowCapturePointModal(true);
      } else {
        endTurn(currentPlayerIndex);
        return;
      }
    }

    const isNPC = currentPlayerIndex !== 0 && gameMode === 'singleplayer';
    if (!rolledDoubles || endedInPow || isNPC) {
      setHasRolled(true);
      // Check if landed on card space
      setPlayers(prev => {
        const p = prev[currentPlayerIndex];
        if ([2, 17, 33].includes(p.position)) {
          setPendingCardDraw('chest');
        } else if ([7, 22, 36].includes(p.position)) {
          setPendingCardDraw('chance');
        }
        return prev;
      });
    } else {
      // If rolled doubles and not in POW, they roll again, but check for cards first
      setPlayers(prev => {
        const p = prev[currentPlayerIndex];
        if ([2, 17, 33].includes(p.position)) {
          setPendingCardDraw('chest');
        } else if ([7, 22, 36].includes(p.position)) {
          setPendingCardDraw('chance');
        }
        return prev;
      });
    }
  };

  const handleDeckClick = (deck: 'chest' | 'chance') => {
    if (pendingCardDraw !== deck) return;
    
    let cardId = 1;
    if (deck === 'chest') {
      cardId = Math.floor(Math.random() * 6) + 1;
    } else {
      cardId = Math.floor(Math.random() * 7) + 1;
      if (cardId === 5) {
        playAudio('/COD MUSIC AND SFX/FASTEST BOUNTY TARGET EVER ELIMINATED_! - Warzone Quads - Call of Duty_ Modern Warfare.mp3');
      } else if (cardId === 7) {
        playAudio('/COD MUSIC AND SFX/striker_droppin_whiske.mp3');
      }
    }
    
    setDrawnCard({ type: deck, id: cardId });
    setPendingCardDraw(null);
  };

  const handlePayRent = () => {
    const space = spaces[currentPlayer.position];
    if (!space || !properties[space.id] || properties[space.id].isMortgaged) return;

    const rent = getRentCost(space, properties[space.id].level);
    if (currentPlayer.money >= rent) {
      playAudio('/COD MUSIC AND SFX/come back anytime.mp3');
      setPlayers(prev => {
        const newPlayers = prev.map(p => ({...p}));
        const ownerIdx = newPlayers.findIndex(p => p.id === properties[space.id].ownerId);
        newPlayers[currentPlayerIndex].money -= rent;
        if (ownerIdx !== -1) {
          newPlayers[ownerIdx].money += rent;
        }
        return newPlayers;
      });
      showToast(`You paid $${rent} rent to ${players.find(p => p.id === properties[space.id].ownerId)?.name}!`);
      setMustPayRent(false);
      setSelectedSpace(null);
      if (currentPlayerIndex !== 0 && gameMode === 'singleplayer') {
        endTurn(currentPlayerIndex);
      }
    } else {
      let totalAssets = currentPlayer.money;
      Object.entries(properties).forEach(([spaceId, prop]) => {
        if (prop.ownerId === currentPlayer.id && !prop.isMortgaged) {
          const s = spaces.find(s => s.id === Number(spaceId));
          if (s) {
            totalAssets += getMortgageValue(s);
          }
        }
      });

      if (totalAssets >= rent) {
        if (currentPlayerIndex !== 0 && gameMode === 'singleplayer') {
          // NPC auto-mortgages
          let currentCash = currentPlayer.money;
          const newProps = { ...properties };
          const propsToMortgage = Object.entries(newProps)
            .filter(([_, prop]) => prop.ownerId === currentPlayer.id && !prop.isMortgaged)
            .sort((a, b) => {
              const sA = spaces.find(s => s.id === Number(a[0]));
              const sB = spaces.find(s => s.id === Number(b[0]));
              return getMortgageValue(sA!) - getMortgageValue(sB!);
            });
          
          for (const [spaceId, prop] of propsToMortgage) {
            if (currentCash >= rent) break;
            const s = spaces.find(s => s.id === Number(spaceId));
            if (s) {
              currentCash += getMortgageValue(s);
              newProps[Number(spaceId)].isMortgaged = true;
              playAudio('/COD MUSIC AND SFX/Resident Evil 4 - Merchant Quotes - Thank You.mp3');
            }
          }
          
          setProperties(newProps);
          setPlayers(prev => {
            const newPlayers = prev.map(p => ({...p}));
            newPlayers[currentPlayerIndex].money = currentCash;
            return newPlayers;
          });
          showToast(`${currentPlayer.name} mortgaged properties to pay rent!`);
          
          // Now that we have enough cash, pay the rent immediately
          playAudio('/COD MUSIC AND SFX/come back anytime.mp3');
          setPlayers(prev => {
            const newPlayers = prev.map(p => ({...p}));
            const ownerIdx = newPlayers.findIndex(p => p.id === properties[space.id].ownerId);
            newPlayers[currentPlayerIndex].money -= rent;
            if (ownerIdx !== -1) {
              newPlayers[ownerIdx].money += rent;
            }
            return newPlayers;
          });
          showToast(`${currentPlayer.name} paid $${rent} rent to ${players.find(p => p.id === properties[space.id].ownerId)?.name}!`);
          setMustPayRent(false);
          setSelectedSpace(null);
          if (currentPlayerIndex !== 0 && gameMode === 'singleplayer') {
            endTurn(currentPlayerIndex);
          }
        } else {
          showToast("You don't have enough cash, but you can mortgage properties to pay rent!");
        }
      } else {
        showToast("Not enough money to pay rent, even if you mortgage everything! You are bankrupt and eliminated!");
        if (gameMode === 'multiplayer' || currentPlayerIndex === 0) {
          setEliminatedPlayerAlert(players[currentPlayerIndex]);
        }
        setPlayers(prev => {
          const newPlayers = prev.map(p => ({...p}));
          const ownerIdx = newPlayers.findIndex(p => p.id === properties[space.id].ownerId);
          if (ownerIdx !== -1) {
            newPlayers[ownerIdx].money += newPlayers[currentPlayerIndex].money;
          }
          newPlayers[currentPlayerIndex].money = 0;
          newPlayers[currentPlayerIndex].isEliminated = true;
          return newPlayers;
        });
        setProperties(prev => {
          const newProps = { ...prev };
          Object.keys(newProps).forEach(key => {
            if (newProps[Number(key)].ownerId === currentPlayer.id) {
              delete newProps[Number(key)];
            }
          });
          return newProps;
        });
        setMustPayRent(false);
        setSelectedSpace(null);
        endTurn(currentPlayerIndex);
      }
    }
  };

  const resolveCard = () => {
    if (!drawnCard) return;
    
    let nextPos = currentPlayer.position;
    if (drawnCard.type === 'chest') {
      if (drawnCard.id === 4) nextPos = 0;
      if (drawnCard.id === 5) nextPos = 10;
    } else {
      if (drawnCard.id === 3) nextPos = (nextPos + 2) % 40;
      if (drawnCard.id === 6) nextPos = 20;
    }

    setPlayers(prev => {
      const newPlayers = prev.map(p => ({...p}));
      const p = newPlayers[currentPlayerIndex];
      
      if (drawnCard.type === 'chest') {
        switch (drawnCard.id) {
          case 1: p.money += 200; break;
          case 2: p.money -= 250; break;
          case 3: p.money += 150; break;
          case 4: p.position = 0; p.money += 200; break; // Advance to GO
          case 5: p.position = 10; p.hasGetOutOfPowCard = true; break;
          case 6: p.money -= 100; break;
        }
      } else {
        switch (drawnCard.id) {
          case 1: p.money -= 200; break;
          case 2: p.money -= 250; break;
          case 3: p.position = (p.position + 2) % 40; break;
          case 4: p.waitTurns = (p.waitTurns || 0) + 2; break;
          case 5: p.money += 300; break;
          case 6: p.position = 20; break; // Helipad
          case 7: 
            setShowPlayerSelect(true);
            return newPlayers; // Don't end turn yet
        }
      }
      
      return newPlayers;
    });

    if (drawnCard.type !== 'chance' || drawnCard.id !== 7) {
      setDrawnCard(null);
      if (properties[nextPos] && properties[nextPos].ownerId !== currentPlayer.id && !properties[nextPos].isMortgaged) {
        setMustPayRent(true);
        setSelectedSpace(spaces[nextPos]);
      } else {
        endTurn(currentPlayerIndex);
      }
    }
  };

  const handlePlayerSelect = (targetId: number) => {
    setPlayers(prev => {
      const newPlayers = prev.map(p => ({...p}));
      const target = newPlayers.find(p => p.id === targetId);
      if (target) {
        target.waitTurns = (target.waitTurns || 0) + 1;
      }
      return newPlayers;
    });
    
    const missileAudio = playAudio('/COD MUSIC AND SFX/Enemy Cruise Missile Incoming.mp3');
    // Assuming explosion cue is around 2 seconds in, we can set the visual effect then
    setTimeout(() => {
      setVisualEffect('missile');
      setEffectTarget(targetId);
      setTimeout(() => {
        setVisualEffect(null);
        setEffectTarget(null);
      }, 1500); // Effect duration
    }, 2000);
    
    setShowPlayerSelect(false);
    setDrawnCard(null);
    endTurn(currentPlayerIndex);
  };

  const getRentCost = (space: SpaceData, level: 'tent' | 'hq') => {
    const isScorestreak = space.type === 'railroad';
    let scorestreakMonopoly = false;
    if (isScorestreak) {
      const ownerId = properties[space.id]?.ownerId;
      if (ownerId !== undefined) {
        const scorestreakIds = [5, 15, 25, 35];
        scorestreakMonopoly = scorestreakIds.every(id => properties[id]?.ownerId === ownerId);
      }
    }

    if (space.name === 'Supply Depot') return scorestreakMonopoly ? Math.floor(150 * 1.5) : 150;
    if (space.name === 'Advance UAV') return scorestreakMonopoly ? Math.floor(300 * 1.5) : 300;
    if (space.name === 'Support Helo') return scorestreakMonopoly ? Math.floor(450 * 1.5) : 450;
    if (space.name === 'Gunship') return scorestreakMonopoly ? Math.floor(600 * 1.5) : 600;

    const isUtility = space.type === 'utility';
    let utilityMonopoly = false;
    if (isUtility) {
      const ownerId = properties[space.id]?.ownerId;
      if (ownerId !== undefined) {
        const utilityIds = [12, 28];
        utilityMonopoly = utilityIds.every(id => properties[id]?.ownerId === ownerId);
      }
    }

    if (space.name === 'Ammunition') return utilityMonopoly ? 225 * 2 : 225;
    if (space.name === 'Military Convoy') return utilityMonopoly ? 300 * 2 : 300;

    if (!space.price) return 0;
    
    let baseRent = level === 'hq' ? Math.floor(space.price * 0.6) : Math.floor(space.price * 0.2);

    if (space.type === 'property' && space.color) {
      const ownerId = properties[space.id]?.ownerId;
      if (ownerId !== undefined) {
        const colorGroupIds = spaces.filter(s => s.color === space.color).map(s => s.id);
        const hasMonopoly = colorGroupIds.every(id => properties[id]?.ownerId === ownerId);
        if (hasMonopoly) {
          baseRent *= 2;
        }
      }
    }

    return baseRent;
  };

  const getMortgageValue = (space: SpaceData) => {
    if (space.name === 'Supply Depot') return 120;
    if (space.name === 'Ammunition') return 150;
    if (space.name === 'Advance UAV') return 200;
    if (space.name === 'Support Helo') return 300;
    if (space.name === 'Military Convoy') return 200;
    if (space.name === 'Gunship') return 400;
    
    return space.price ? Math.floor(space.price / 2) : 0;
  };

  // NPC Trade AI Loop
  useEffect(() => {
    if (gameMode !== 'singleplayer' && !(lobbyPlayers?.find(p => p.id === localUserId)?.isHost)) return;

    const npcTrade = activeTrades.find(t => {
      const rec = players.find(p => p.id === t.receiverId);
      return t.status === 'pending' && rec?.isNPC;
    });

    if (npcTrade) {
      const timer = setTimeout(() => {
        const rec = players.find(p => p.id === npcTrade.receiverId);
        if (!rec) return;

        // AI evaluation: Sufficient funds check
        if (rec.money >= npcTrade.requestedMoney) {
          handleTradeResponse(npcTrade.id, 'accept');
        } else {
          handleTradeResponse(npcTrade.id, 'decline');
        }
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [activeTrades, players, gameMode, lobbyPlayers, localUserId]);

  useEffect(() => {
    if (currentView !== 'game' || gameOver || isPaused) return;

    const isCurrentNPC = (gameMode === 'singleplayer' && currentPlayerIndex !== 0) || currentPlayer.isNPC;
    if (!isCurrentNPC) return;

    const npcTurn = setTimeout(() => {
      if (!hasRolled) {
        if (currentPlayer.powStatus === 'captured_needs_choice') {
          if (currentPlayer.hasGetOutOfPowCard) {
            setPlayers(prev => {
              const newPlayers = prev.map(p => ({...p}));
              newPlayers[currentPlayerIndex].powStatus = 'free';
              newPlayers[currentPlayerIndex].hasGetOutOfPowCard = false;
              return newPlayers;
            });
            showToast(`${currentPlayer.name} used a Top Secret File to escape POW Camp!`);
            endTurn(currentPlayerIndex);
          } else {
            const choice = Math.random() > 0.5 ? 'escape' : 'wait';
            if (choice === 'escape') {
              const d1 = Math.floor(Math.random() * 6) + 1;
              const d2 = Math.floor(Math.random() * 6) + 1;
              setDice([d1, d2]);
              const total = d1 + d2;
              
              setPlayers(prev => {
                const newPlayers = prev.map(p => ({...p}));
                const p = newPlayers[currentPlayerIndex];
                if (total >= 8) {
                  p.powStatus = 'free';
                  showToast(`${currentPlayer.name} rolled a ${total}! They escaped the POW Camp!`);
                } else {
                  p.isEliminated = true;
                  setProperties(prevProps => {
                    const newProps = { ...prevProps };
                    Object.keys(newProps).forEach(key => {
                      if (newProps[Number(key)].ownerId === p.id) {
                        delete newProps[Number(key)];
                      }
                    });
                    return newProps;
                  });
                  showToast(`${currentPlayer.name} rolled a ${total} and was eliminated from the game!`);
                  setTimeout(() => endTurn(currentPlayerIndex), 100);
                }
                return newPlayers;
              });
            } else {
              setPlayers(prev => {
                const newPlayers = prev.map(p => ({...p}));
                const p = newPlayers[currentPlayerIndex];
                p.powStatus = 'captured_waiting';
                p.waitTurns = 2;
                return newPlayers;
              });
              showToast(`${currentPlayer.name} chose to wait for rescue (Skip 2 Turns).`);
              endTurn(currentPlayerIndex);
            }
          }
        } else {
          rollDice();
        }
      } else {
        if (mustPayRent) {
          handlePayRent();
        } else if (showCapturePointModal) {
          setShowCapturePointModal(false);
          endTurn(currentPlayerIndex);
        } else if (pendingCardDraw) {
          const deck = pendingCardDraw;
          let cardId;
          if (deck === 'chest') {
            cardId = Math.floor(Math.random() * 6) + 1;
          } else {
            cardId = Math.floor(Math.random() * 7) + 1;
            if (cardId === 5) {
              playAudio('/COD MUSIC AND SFX/FASTEST BOUNTY TARGET EVER ELIMINATED_! - Warzone Quads - Call of Duty_ Modern Warfare.mp3');
            } else if (cardId === 7) {
              playAudio('/COD MUSIC AND SFX/striker_droppin_whiske.mp3');
            }
          }
          setDrawnCard({ type: deck, id: cardId });
          setPendingCardDraw(null);
        } else if (drawnCard) {
          if (showPlayerSelect) {
            const otherPlayers = players.filter(p => p.id !== currentPlayer.id && !p.isEliminated);
            if (otherPlayers.length > 0) {
              const target = otherPlayers[Math.floor(Math.random() * otherPlayers.length)];
              handlePlayerSelect(target.id);
            } else {
              setDrawnCard(null);
              setShowPlayerSelect(false);
              endTurn(currentPlayerIndex);
            }
          } else {
            resolveCard();
          }
        } else {
          const space = spaces[currentPlayer.position];
          if (space && space.type === 'property' && !properties[space.id] && space.price) {
            if (currentPlayer.money >= space.price + 200) {
              setPlayers(prev => {
                const newPlayers = prev.map(p => ({...p}));
                newPlayers[currentPlayerIndex].money -= space.price!;
                return newPlayers;
              });
              setProperties(prev => ({
                ...prev,
                [space.id]: { ownerId: currentPlayer.id, level: 'tent' }
              }));
              showToast(`${currentPlayer.name} bought ${space.name}!`);
            }
          }
          endTurn(currentPlayerIndex);
        }
      }
    }, 1500);

    return () => clearTimeout(npcTurn);
  }, [currentPlayerIndex, gameMode, currentView, gameOver, isPaused, hasRolled, mustPayRent, showCapturePointModal, pendingCardDraw, drawnCard, showPlayerSelect]);

  return (
    <div 
      className="min-h-screen bg-neutral-900 text-white flex items-center justify-center p-8 font-sans transition-all relative overflow-hidden"
      style={{ 
        filter: `brightness(${brightness})`,
        backgroundImage: (currentView === 'main_menu' || currentView === 'lobby' || currentView === 'login') ? 'url("/COD BACKGROUND/Background COD.png")' : 'none',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat'
      }}
    >
      {toastMessage && (
        <div className="fixed top-4 left-1/2 transform -translate-x-1/2 bg-blue-600 text-white px-6 py-3 rounded-lg shadow-2xl z-[200] font-bold animate-in fade-in slide-in-from-top-4 duration-300">
          {toastMessage}
        </div>
      )}
      
      {currentView === 'login' && (
        <div className="absolute inset-0 flex justify-between items-end pointer-events-none opacity-40 overflow-hidden">
          <img src="/COD BACKGROUND/1-removebg-preview.png" alt="Background 1" className="w-1/2 h-full object-cover object-left-bottom" />
          <img src="/COD BACKGROUND/2-removebg-preview.png" alt="Background 2" className="w-1/2 h-full object-cover object-right-bottom" />
        </div>
      )}

      {currentView === 'login' ? (
        <div className="flex flex-col items-center justify-center w-full max-w-md animate-in fade-in zoom-in duration-500 relative z-10">
          <h1 
            className="text-6xl font-black uppercase tracking-widest mb-12 text-center drop-shadow-[0_0_10px_rgba(255,255,255,0.5)]"
            style={{
              backgroundColor: '#0c2612',
              color: '#000000',
              fontFamily: 'Courier New',
              textDecorationLine: 'line-through'
            }}
          >
            Call of Duty<br/>Monopoly
          </h1>
          <div className="bg-neutral-800 p-8 rounded-xl border-2 border-neutral-600 w-full shadow-2xl flex flex-col gap-6">
            <h2 className="text-2xl font-bold text-center mb-2">LOGIN</h2>
            <div>
              <label className="block text-sm text-neutral-400 mb-1">Email</label>
              <input 
                type="email" 
                placeholder="Enter your email" 
                value={loginUsername}
                onChange={(e) => setLoginUsername(e.target.value)}
                className="w-full bg-neutral-700 border border-neutral-600 rounded p-3 text-white focus:outline-none focus:border-blue-500 transition-colors"
              />
            </div>
            <div>
              <label className="block text-sm text-neutral-400 mb-1">Password</label>
              <input 
                type="password" 
                placeholder="Enter your password" 
                value={loginPassword}
                onChange={(e) => setLoginPassword(e.target.value)}
                className="w-full bg-neutral-700 border border-neutral-600 rounded p-3 text-white focus:outline-none focus:border-blue-500 transition-colors"
              />
            </div>
            {loginError && <p className="text-red-500 text-sm text-center">{loginError}</p>}
            <div className="flex flex-col gap-3 mt-4">
              <button 
                onClick={async () => {
                  if (!loginUsername || !loginPassword) {
                    setLoginError('Email and password are required');
                    return;
                  }
                  try {
                    await signInWithEmailAndPassword(auth, loginUsername, loginPassword);
                    setLoginError('');
                    setCurrentView('main_menu');
                  } catch (error: any) {
                    setLoginError(error.message);
                  }
                }}
                className="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-lg transition-colors"
              >
                Sign In
              </button>
              <button 
                onClick={async () => {
                  if (!loginUsername || !loginPassword) {
                    setLoginError('Email and password are required');
                    return;
                  }
                  try {
                    await createUserWithEmailAndPassword(auth, loginUsername, loginPassword);
                    setLoginError('');
                    setCurrentView('main_menu');
                  } catch (error: any) {
                    setLoginError(error.message);
                  }
                }}
                className="w-full py-3 bg-neutral-600 hover:bg-neutral-500 text-white font-bold rounded-lg transition-colors"
              >
                Sign Up
              </button>
            </div>
          </div>
        </div>
      ) : currentView === 'main_menu' ? (
        <div className="flex flex-col items-center justify-center w-full max-w-md animate-in fade-in zoom-in duration-500 relative z-10">
          <h1 
            className="text-6xl font-black uppercase tracking-widest mb-12 text-center drop-shadow-[0_0_10px_rgba(255,255,255,0.5)]"
            style={{
              backgroundColor: '#0c2612',
              color: '#000000',
              fontFamily: 'Courier New',
              textDecorationLine: 'line-through'
            }}
          >
            Call of Duty<br/>Monopoly
          </h1>
          <div className="flex flex-col gap-6 w-full">
            <button 
              onClick={() => startNewGame('singleplayer')}
              className="w-full py-4 bg-neutral-800 hover:bg-neutral-700 border-2 border-neutral-600 text-white font-bold text-xl uppercase tracking-wider rounded-lg transition-all hover:scale-105 active:scale-95"
            >
              Singleplayer
            </button>
            <button 
              onClick={() => setShowMultiplayerModal(true)}
              className="w-full py-4 bg-neutral-800 hover:bg-neutral-700 border-2 border-neutral-600 text-white font-bold text-xl uppercase tracking-wider rounded-lg transition-all hover:scale-105 active:scale-95"
            >
              Multiplayer
            </button>
            <button 
              onClick={() => setShowSettings(true)}
              className="w-full py-4 bg-neutral-800 hover:bg-neutral-700 border-2 border-neutral-600 text-white font-bold text-xl uppercase tracking-wider rounded-lg transition-all hover:scale-105 active:scale-95"
            >
              Settings
            </button>
            <button 
              onClick={() => setCurrentView('login')}
              className="w-full py-4 bg-red-900 hover:bg-red-800 border-2 border-red-700 text-white font-bold text-xl uppercase tracking-wider rounded-lg transition-all hover:scale-105 active:scale-95 mt-8"
            >
              Log Out
            </button>
          </div>

          {showMultiplayerModal && (
            <div className="fixed inset-0 bg-black/90 z-[100] flex items-center justify-center p-4 backdrop-blur-md">
              <div className="bg-neutral-800 p-8 rounded-xl border-2 border-neutral-600 max-w-sm w-full shadow-2xl flex flex-col gap-4 relative">
                <button 
                  onClick={() => {
                    setShowMultiplayerModal(false);
                    setShowOnlineOptions(false);
                  }} 
                  className="absolute top-4 right-4 text-neutral-400 hover:text-white transition-colors"
                >
                  <X className="w-6 h-6" />
                </button>
                <h2 className="text-3xl font-black uppercase tracking-widest text-white mb-4 text-center">Multiplayer</h2>
                {!showOnlineOptions ? (
                  <>
                    <button 
                      onClick={() => {
                        setShowMultiplayerModal(false);
                        startNewGame('multiplayer');
                      }}
                      className="w-full py-4 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xl uppercase tracking-wider rounded-lg transition-all hover:scale-105 active:scale-95"
                    >
                      Offline
                    </button>
                    <button 
                      onClick={() => setShowOnlineOptions(true)}
                      className="w-full py-4 bg-green-600 hover:bg-green-500 text-white font-bold text-xl uppercase tracking-wider rounded-lg transition-all hover:scale-105 active:scale-95"
                    >
                      Online
                    </button>
                  </>
                ) : (
                  <>
                    <div className="flex flex-col gap-2 mb-4">
                      <label className="text-sm text-neutral-400 uppercase tracking-wider">Join Lobby</label>
                      <div className="flex gap-2">
                        <input 
                          type="text" 
                          placeholder="Lobby Code" 
                          value={joinLobbyInput}
                          onChange={(e) => setJoinLobbyInput(e.target.value.toUpperCase())}
                          className="flex-1 bg-neutral-700 border border-neutral-600 rounded p-3 text-white focus:outline-none focus:border-green-500 font-mono text-center uppercase"
                        />
                        <button 
                          onClick={() => {
                            if (!joinLobbyInput) return;
                            const code = joinLobbyInput.toUpperCase();
                            get(ref(db, `lobbies/${code}`)).then((snapshot) => {
                              if (snapshot.exists()) {
                                const lobby = snapshot.val();
                                const currentPlayers = lobby.players || [];
                                if (currentPlayers.length >= 4) {
                                  alert('This lobby is full!'); // Ensure maximum 4 players
                                } else {
                                  const newId = Math.max(...currentPlayers.map((p: any) => p.id), 0) + 1;
                                  const newLocalUser = { id: newId, name: loginUsername || 'Player ' + newId, isHost: false };
                                  currentPlayers.push(newLocalUser);
                                  set(ref(db, `lobbies/${code}/players`), currentPlayers).then(() => {
                                    setLocalUserId(newLocalUser.id);
                                    setLobbyCode(code);
                                    setLobbyPlayers(currentPlayers);
                                    setShowMultiplayerModal(false);
                                    setShowOnlineOptions(false);
                                    setCurrentView('lobby');
                                    // Remove user on disconnect
                                    const userIndex = currentPlayers.length - 1;
                                    onDisconnect(ref(db, `lobbies/${code}/players/${userIndex}`)).remove();
                                  });
                                }
                              } else {
                                alert('Lobby not found!');
                              }
                            });
                          }}
                          className="bg-green-600 hover:bg-green-500 text-white font-bold px-6 rounded-lg transition-colors"
                        >
                          Join
                        </button>
                      </div>
                    </div>
                    <div className="relative flex items-center py-2">
                      <div className="flex-grow border-t border-neutral-600"></div>
                      <span className="flex-shrink-0 mx-4 text-neutral-500">OR</span>
                      <div className="flex-grow border-t border-neutral-600"></div>
                    </div>
                    <button 
                      onClick={() => {
                        const hostName = loginUsername || 'Player 1';
                        const code = Math.random().toString(36).substring(2, 8).toUpperCase();
                        const initialHost = { id: 1, name: hostName, isHost: true };
                        
                        const lobbyData = {
                          host: hostName,
                          players: [initialHost],
                          status: 'waiting',
                          createdAt: Date.now()
                        };
                        
                        set(ref(db, `lobbies/${code}`), lobbyData).then(() => {
                           setLocalUserId(1);
                           setLobbyCode(code);
                           setLobbyPlayers([initialHost]);
                           setShowMultiplayerModal(false);
                           setShowOnlineOptions(false);
                           setCurrentView('lobby');
                           
                           // Clean up entire lobby on host disconnect
                           onDisconnect(ref(db, `lobbies/${code}`)).remove();
                        });
                      }}
                      className="w-full py-4 bg-purple-600 hover:bg-purple-500 text-white font-bold text-xl uppercase tracking-wider rounded-lg transition-all hover:scale-105 active:scale-95 mt-2"
                    >
                      Host Lobby
                    </button>
                    <button 
                      onClick={() => setShowOnlineOptions(false)}
                      className="w-full py-2 bg-neutral-700 hover:bg-neutral-600 text-white font-bold uppercase tracking-wider rounded-lg transition-all mt-4"
                    >
                      Back
                    </button>
                  </>
                )}
              </div>
            </div>
          )}
        </div>
      ) : currentView === 'lobby' ? (
        <div className="flex flex-col items-center justify-center w-full max-w-2xl animate-in fade-in zoom-in duration-500 relative z-10">
          <div className="bg-neutral-800 p-8 rounded-xl border-2 border-neutral-600 w-full shadow-2xl">
            <h2 className="text-4xl font-black uppercase tracking-widest text-white mb-6 text-center">Matchmaking Lobby</h2>
            
            <div className="bg-neutral-900 p-4 rounded-lg border border-neutral-700 mb-8 flex flex-col items-center">
              <span className="text-neutral-400 uppercase tracking-wider text-sm mb-2">Lobby Code</span>
              <div className="text-5xl font-mono font-bold tracking-widest text-green-500">{lobbyCode}</div>
              <p className="text-sm text-neutral-500 mt-2">Share this code with others to join</p>
            </div>

            <div className="mb-8">
              <h3 className="text-xl font-bold mb-4 text-neutral-300 flex justify-between items-center">
                <span>Players ({lobbyPlayers.length}/4)</span>
                {/* Simulate Join Button for local testing */}
                {lobbyPlayers.length < 4 && (
                  <button 
                    onClick={() => {
                      const newId = Math.max(...lobbyPlayers.map(p => p.id), 0) + 1;
                      const bot = { id: newId, name: `Player ${newId}`, isHost: false };
                      set(ref(db, `lobbies/${lobbyCode}/players`), [...lobbyPlayers, bot]);
                    }}
                    className="text-sm bg-blue-600 hover:bg-blue-500 px-3 py-1 rounded text-white transition-colors"
                  >
                    + Simulate Join
                  </button>
                )}
              </h3>
              <div className="space-y-3">
                {lobbyPlayers.map((player) => (
                  <div key={player.id} className="flex items-center justify-between bg-neutral-900 p-4 rounded-lg border border-neutral-700">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-neutral-700 flex items-center justify-center font-bold">
                        {player.name.charAt(0).toUpperCase()}
                      </div>
                      <span className="font-bold text-lg">{player.name} {player.id === localUserId && '(You)'}</span>
                      {player.isHost && (
                        <span className="bg-yellow-600 text-white text-xs px-2 py-1 rounded uppercase tracking-wider font-bold ml-2">Host</span>
                      )}
                    </div>
                    {/* Host controls */}
                    {lobbyPlayers.find(p => p.id === localUserId)?.isHost && player.id !== localUserId && (
                      <button 
                        onClick={() => {
                          set(ref(db, `lobbies/${lobbyCode}/players`), lobbyPlayers.filter(p => p.id !== player.id));
                        }}
                        className="bg-red-600 hover:bg-red-500 text-white px-3 py-1 rounded text-sm font-bold transition-colors"
                      >
                        Kick
                      </button>
                    )}
                  </div>
                ))}
                {Array.from({ length: 4 - lobbyPlayers.length }).map((_, i) => (
                  <div key={`empty-${i}`} className="flex items-center justify-center bg-neutral-900/50 p-4 rounded-lg border border-neutral-800 border-dashed">
                    <span className="text-neutral-600 font-bold uppercase tracking-wider">Waiting for player...</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex gap-4">
              <button 
                onClick={() => {
                  const updatedPlayers = lobbyPlayers.filter(p => p.id !== localUserId);
                  if (updatedPlayers.length === 0) {
                     remove(ref(db, `lobbies/${lobbyCode}`));
                  } else {
                     if (lobbyPlayers.find(p => p.id === localUserId)?.isHost) {
                        updatedPlayers[0].isHost = true;
                     }
                     set(ref(db, `lobbies/${lobbyCode}/players`), updatedPlayers);
                  }
                  setLobbyCode('');
                  setCurrentView('main_menu');
                }}
                className="flex-1 py-4 bg-red-600 hover:bg-red-500 text-white font-bold text-xl uppercase tracking-wider rounded-lg transition-all"
              >
                Leave Lobby
              </button>
              <button 
                onClick={() => {
                  // Start game logic
                  const isHost = lobbyPlayers.find(p => p.id === localUserId)?.isHost;
                  if (isHost && lobbyPlayers.length >= 1) {
                    // Setup players based on lobby
                    let newPlayers = lobbyPlayers.map((lp, index) => ({
                      ...initialPlayers[index],
                      id: lp.id,
                      name: lp.name,
                      isEliminated: false,
                      money: 1500,
                      position: 0,
                      powStatus: 'free' as const,
                      waitTurns: 0,
                      isNPC: false
                    }));
                    
                    // Fill remaining slots with NPCs
                    while (newPlayers.length < 4) {
                      const idx = newPlayers.length;
                      newPlayers.push({
                        ...initialPlayers[idx],
                        id: Math.max(...newPlayers.map(p => p.id), 0) + 1,
                        name: initialPlayers[idx].name + ' (Bot)',
                        isEliminated: false,
                        money: 1500,
                        position: 0,
                        powStatus: 'free' as const,
                        waitTurns: 0,
                        isNPC: true
                      });
                    }
                    
                    update(ref(db, `lobbies/${lobbyCode}`), { status: 'playing', gamePlayers: newPlayers });
                  }
                }}
                disabled={!(lobbyPlayers.find(p => p.id === localUserId)?.isHost) || lobbyPlayers.length < 1}
                className={`flex-1 py-4 font-bold text-xl uppercase tracking-wider rounded-lg transition-all ${
                  (lobbyPlayers.find(p => p.id === localUserId)?.isHost) && lobbyPlayers.length >= 1
                    ? 'bg-green-600 hover:bg-green-500 text-white hover:scale-105 active:scale-95' 
                    : 'bg-neutral-700 text-neutral-500 cursor-not-allowed'
                }`}
              >
                Start Game
              </button>
            </div>
          </div>
        </div>
      ) : (
        <>
          {/* Menu Button */}
          <button
            onClick={() => {
              setIsPaused(true);
              setShowMenu(true);
            }}
            className="absolute top-4 left-4 z-40 bg-neutral-800 hover:bg-neutral-700 border border-neutral-600 px-4 py-2 rounded font-bold transition-colors"
          >
            Menu
          </button>

          {/* Menu Overlay */}
          {showMenu && (
            <div className="fixed inset-0 bg-black/90 z-[100] flex items-center justify-center p-4 backdrop-blur-md">
              <div className="bg-neutral-800 p-8 rounded-xl border-2 border-neutral-600 max-w-sm w-full text-center shadow-2xl flex flex-col gap-4">
                <h2 className="text-3xl font-black uppercase tracking-widest text-white mb-4">Menu</h2>
                
                <button
                  onClick={() => {
                    setShowMenu(false);
                    setIsPaused(false);
                  }}
                  className="w-full py-3 bg-green-600 hover:bg-green-500 text-white font-bold rounded-lg transition-colors"
                >
                  Resume Game
                </button>
                
                <button
                  onClick={() => {
                    setShowMenu(false);
                    setShowSettings(true);
                  }}
                  className="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-lg transition-colors"
                >
                  Settings
                </button>
                
                <button
                  onClick={() => {
                    if (gameMode === 'multiplayer') {
                      const updatedPlayers = lobbyPlayers.filter(p => p.id !== localUserId);
                      if (updatedPlayers.length === 0) {
                         remove(ref(db, `lobbies/${lobbyCode}`));
                      } else {
                         if (lobbyPlayers.find(p => p.id === localUserId)?.isHost) {
                            updatedPlayers[0].isHost = true;
                         }
                         set(ref(db, `lobbies/${lobbyCode}/players`), updatedPlayers);
                      }
                      setLobbyCode('');
                    } else {
                      const activePlayers = players.filter(p => !p.isEliminated);
                      if (activePlayers.length <= 1) {
                        // Reset game
                        setPlayers(initialPlayers);
                        setCurrentPlayerIndex(0);
                        setProperties({});
                        setGameOver(false);
                        setTwoPlayerAnnouncementMade(false);
                        setRestartVotes([]);
                        setRestartTimer(20);
                      } else {
                        // Current player leaves
                        setPlayers(prev => {
                          const newPlayers = prev.map(p => ({...p}));
                          newPlayers[currentPlayerIndex].isEliminated = true;
                          newPlayers[currentPlayerIndex].money = 0;
                          return newPlayers;
                        });
                        setProperties(prev => {
                          const newProps = { ...prev };
                          Object.keys(newProps).forEach(key => {
                            if (newProps[Number(key)].ownerId === currentPlayer.id) {
                              delete newProps[Number(key)];
                            }
                          });
                          return newProps;
                        });
                        endTurn(currentPlayerIndex);
                      }
                    }
                    setShowMenu(false);
                    setIsPaused(false);
                    setCurrentView('main_menu');
                  }}
                  className="w-full py-3 bg-red-600 hover:bg-red-500 text-white font-bold rounded-lg transition-colors mt-4"
                >
                  Leave / Exit Game
                </button>
              </div>
            </div>
          )}

          {/* Settings Overlay was here */}

      {/* Card Modal */}
      {drawnCard && !showPlayerSelect && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
          <div className="bg-neutral-800 p-6 rounded-xl border-2 border-neutral-600 max-w-sm w-full flex flex-col items-center shadow-2xl animate-in fade-in zoom-in duration-300">
            <h2 className="text-2xl font-black uppercase tracking-widest mb-4 text-center">
              {drawnCard.type === 'chest' ? 'Top Secret File' : 'Radio Transmission'}
            </h2>
            <div className="w-64 h-40 bg-neutral-700 border-2 border-neutral-500 rounded-lg mb-6 flex items-center justify-center overflow-hidden relative">
              <img 
                src={drawnCard.type === 'chest' 
                  ? `/COD COMMUNITY CHEST CARDS/Community Chest Card ${drawnCard.id}.png` 
                  : `/COD CHANCE CARDS/Chance Card ${drawnCard.id}.png`} 
                alt="Card"
                className="w-full h-full object-cover"
                onError={(e) => {
                  (e.target as HTMLImageElement).style.display = 'none';
                  (e.target as HTMLImageElement).nextElementSibling?.classList.remove('hidden');
                }}
              />
              <div className="hidden absolute inset-0 flex items-center justify-center text-neutral-400 font-bold text-center p-4">
                [Placeholder for {drawnCard.type === 'chest' ? 'Community Chest' : 'Chance'} Card {drawnCard.id}]
              </div>
            </div>
            {currentPlayer.id === localUserId ? (
              <button 
                onClick={resolveCard}
                className="w-full py-3 bg-white text-black font-bold rounded-lg hover:bg-neutral-200 transition-colors active:scale-95"
              >
                Acknowledge
              </button>
            ) : (
              <button 
                disabled
                className="w-full py-3 bg-neutral-700 text-neutral-400 font-bold rounded-lg cursor-not-allowed"
              >
                Waiting for {currentPlayer.name}...
              </button>
            )}
          </div>
        </div>
      )}

      {/* Player Select Modal for Chance Card 7 */}
      {showPlayerSelect && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
          <div className="bg-neutral-800 p-6 rounded-xl border-2 border-neutral-600 max-w-sm w-full flex flex-col items-center shadow-2xl animate-in fade-in zoom-in duration-300">
            <h2 className="text-xl font-black uppercase tracking-widest mb-4 text-center text-red-400">
              Target Acquired
            </h2>
            <p className="text-center text-neutral-300 mb-6">Select a player to skip their next turn:</p>
            {currentPlayer.id === localUserId ? (
              <div className="flex flex-col gap-3 w-full">
                {players.filter(p => p.id !== currentPlayer.id && !p.isEliminated).map(p => (
                  <button
                    key={p.id}
                    onClick={() => handlePlayerSelect(p.id)}
                    className={`w-full py-3 ${p.color} text-white font-bold rounded-lg hover:brightness-110 transition-all active:scale-95 flex items-center justify-center gap-3`}
                  >
                    {p.tokenUrl ? (
                      <img src={p.tokenUrl} alt={p.name} className="w-8 h-8 object-contain drop-shadow-md" />
                    ) : (
                      <div className="w-5 h-5 rounded-full border-2 border-white bg-black/20" />
                    )}
                    {p.name}
                  </button>
                ))}
              </div>
            ) : (
              <div className="w-full py-4 bg-neutral-900 border border-neutral-700 rounded-lg text-center">
                <span className="text-neutral-400 font-bold animate-pulse">Waiting for {currentPlayer.name}...</span>
              </div>
            )}
          </div>
        </div>
      )}

      <div className="flex gap-8 w-full max-w-[1400px]">
        {/* Left Side - Board */}
        <div className="flex-1 flex items-center justify-center relative">
          <Board 
            players={players} 
            properties={properties}
            onSpaceClick={setSelectedSpace} 
            onDeckClick={handleDeckClick}
            pendingCardDraw={pendingCardDraw}
            visualEffect={visualEffect}
            effectTarget={effectTarget}
          />
          {visualEffect === 'nuke' && (
            <div className="absolute inset-0 z-50 flex items-center justify-center pointer-events-none">
              <div className="w-full h-full bg-orange-500/30 animate-pulse absolute" />
              <div className="w-64 h-64 bg-orange-500 rounded-full blur-3xl opacity-80 animate-ping" />
              <div className="text-9xl">🍄💥</div>
            </div>
          )}
        </div>

        {/* Right Side - Controls & Info */}
        <div className="w-80 flex flex-col gap-6">
          <div className="bg-neutral-800 p-6 rounded-xl border border-neutral-700 shadow-xl">
            <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
              <Dice5 className="w-6 h-6" />
              Game Controls
            </h2>
            
            <div className="mb-6 flex justify-between items-center">
              <div>
                <p className="text-neutral-400 mb-1">Current Turn</p>
                <div className="flex items-center gap-3">
                  <div className={`w-4 h-4 rounded-full ${currentPlayer.color}`} />
                  <span className="text-xl font-bold">{currentPlayer.name}</span>
                </div>
              </div>
              <div className="flex flex-col items-end">
                <p className="text-neutral-400 mb-1 text-sm flex items-center gap-1"><Clock className="w-4 h-4" /> Time Left</p>
                <span className={`text-2xl font-black ${timeLeft <= 10 ? 'text-red-500 animate-pulse' : 'text-white'}`}>
                  {Math.floor(timeLeft / 60)}:{(timeLeft % 60).toString().padStart(2, '0')}
                </span>
              </div>
            </div>

            <div className="flex gap-4 mb-6">
              <div className="flex-1 bg-neutral-900 rounded-lg p-4 text-center border border-neutral-700">
                <span className="text-3xl font-black">{dice[0]}</span>
              </div>
              <div className="flex-1 bg-neutral-900 rounded-lg p-4 text-center border border-neutral-700">
                <span className="text-3xl font-black">{dice[1]}</span>
              </div>
            </div>

            {!currentPlayer.isEliminated && currentPlayer.powStatus !== 'captured_needs_choice' && currentPlayer.id === localUserId && (
              <div className="flex flex-col gap-3">
                {[5, 15, 25, 35].every(id => properties[id]?.ownerId === currentPlayer.id) && !currentPlayer.hasUsedNuke && (
                  <button 
                    onClick={() => {
                      setPlayers(prev => {
                        const newPlayers = prev.map(p => ({...p}));
                        newPlayers.forEach(p => {
                          if (p.id !== currentPlayer.id && !p.isEliminated) {
                            p.waitTurns = (p.waitTurns || 0) + 1;
                          }
                        });
                        newPlayers[currentPlayerIndex].hasUsedNuke = true;
                        return newPlayers;
                      });
                      
                      const nukeAudio = playAudio('/COD MUSIC AND SFX/Tactical Nuke Incoming Sound Effect.mp3');
                      // Wait for explosion cue (approx 5 seconds in)
                      setTimeout(() => {
                        setVisualEffect('nuke');
                        setTimeout(() => setVisualEffect(null), 2000); // 2 seconds explosion
                      }, 5000);
                    }}
                    className="w-full py-3 bg-yellow-500 text-black font-black rounded-lg hover:bg-yellow-400 transition-colors active:scale-95 animate-pulse"
                  >
                    LAUNCH NUKE
                  </button>
                )}
                {!hasRolled && (
                  <button 
                    onClick={rollDice}
                    className="w-full py-3 bg-white text-black font-bold rounded-lg hover:bg-neutral-200 transition-colors active:scale-95"
                  >
                    Roll Dice
                  </button>
                )}
                {hasRolled && mustPayRent && (
                  <button 
                    onClick={handlePayRent}
                    className="w-full py-3 bg-red-600 text-white font-bold rounded-lg hover:bg-red-500 transition-colors active:scale-95"
                  >
                    Pay Rent
                  </button>
                )}
                {hasRolled && (
                  <button 
                    onClick={() => endTurn(currentPlayerIndex)}
                    disabled={mustPayRent}
                    className={`w-full py-3 ${mustPayRent ? 'bg-neutral-600 text-neutral-400 cursor-not-allowed' : 'bg-red-600 text-white hover:bg-red-500'} font-bold rounded-lg transition-colors active:scale-95`}
                  >
                    {mustPayRent ? 'Must Pay Rent First' : 'End Turn'}
                  </button>
                )}
                <button 
                  onClick={() => setShowTradeModal(true)}
                  className="w-full py-2 bg-blue-600 text-white font-bold rounded-lg hover:bg-blue-500 transition-colors active:scale-95"
                >
                  Trade / Negotiate
                </button>
              </div>
            )}

            {currentPlayer.powStatus === 'captured_needs_choice' && !currentPlayer.isEliminated && (
              currentPlayer.id === localUserId ? (
                <div className="mt-4 p-4 bg-red-900/40 border border-red-500 rounded-lg text-center animate-pulse">
                  <h3 className="text-xl font-bold text-red-400 mb-2">CAPTURED!</h3>
                <p className="text-sm text-neutral-300 mb-4">You are in the POW Camp. Choose your fate:</p>
                <div className="flex flex-col gap-3">
                  {currentPlayer.hasGetOutOfPowCard && (
                    <button
                      onClick={() => {
                        setPlayers(prev => {
                          const newPlayers = prev.map(p => ({...p}));
                          const p = newPlayers[currentPlayerIndex];
                          p.powStatus = 'free';
                          p.hasGetOutOfPowCard = false;
                          return newPlayers;
                        });
                        alert("You used your Top Secret File to escape the POW Camp!");
                        endTurn(currentPlayerIndex);
                      }}
                      className="w-full py-2 bg-yellow-600 hover:bg-yellow-500 text-white font-bold rounded transition-colors border border-yellow-400"
                    >
                      Use Top Secret File to Escape
                    </button>
                  )}
                  <button
                    onClick={() => {
                      const d1 = Math.floor(Math.random() * 6) + 1;
                      const d2 = Math.floor(Math.random() * 6) + 1;
                      setDice([d1, d2]);
                      const total = d1 + d2;
                      
                      setPlayers(prev => {
                        const newPlayers = prev.map(p => ({...p}));
                        const p = newPlayers[currentPlayerIndex];
                        if (total >= 8) {
                          p.powStatus = 'free';
                          alert(`You rolled a ${total}! You escaped the POW Camp! Roll again to move.`);
                        } else {
                          p.isEliminated = true;
                          if (gameMode === 'multiplayer' || currentPlayerIndex === 0) {
                            setEliminatedPlayerAlert(p);
                          }
                          setProperties(prevProps => {
                            const newProps = { ...prevProps };
                            Object.keys(newProps).forEach(key => {
                              if (newProps[Number(key)].ownerId === p.id) {
                                delete newProps[Number(key)];
                              }
                            });
                            return newProps;
                          });
                          alert(`You rolled a ${total}. You were eliminated from the game!`);
                          setTimeout(() => endTurn(currentPlayerIndex), 100);
                        }
                        return newPlayers;
                      });
                    }}
                    className="w-full py-2 bg-red-600 hover:bg-red-500 text-white font-bold rounded transition-colors"
                  >
                    Escape (Roll 8-12)
                  </button>
                  <button
                    onClick={() => {
                      setPlayers(prev => {
                        const newPlayers = prev.map(p => ({...p}));
                        const p = newPlayers[currentPlayerIndex];
                        p.powStatus = 'captured_waiting';
                        p.waitTurns = 2;
                        return newPlayers;
                      });
                      endTurn(currentPlayerIndex);
                    }}
                    className="w-full py-2 bg-neutral-600 hover:bg-neutral-500 text-white font-bold rounded transition-colors"
                  >
                    Wait for Rescue (Skip 2 Turns)
                  </button>
                </div>
              </div>
            ) : (
              <div className="mt-4 p-4 bg-red-900/20 border border-red-900 rounded-lg text-center">
                <h3 className="text-xl font-bold text-red-500 mb-2">IN POW CAMP</h3>
                <p className="text-sm text-neutral-400">Waiting for {currentPlayer.name} to make a decision...</p>
              </div>
            ))}
          </div>

          <div className="bg-neutral-800 p-6 rounded-xl border border-neutral-700 flex-1 shadow-xl">
            <h3 className="text-xl font-bold mb-4">Players</h3>
            <div className="flex flex-col gap-3">
              {players.map((p, i) => (
                <div 
                  key={p.id} 
                  className={`flex items-center justify-between p-3 rounded-lg border transition-colors ${
                    i === currentPlayerIndex ? 'border-white bg-neutral-700' : 'border-neutral-700 bg-neutral-900'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-3 h-3 rounded-full ${p.color}`} />
                    <span className="font-semibold flex items-center gap-2">
                      {p.name}
                      {p.hasGetOutOfPowCard && !p.isEliminated && (
                        <span className="text-[10px] bg-yellow-600 text-white px-1.5 py-0.5 rounded uppercase tracking-wider font-bold" title="Has Top Secret File (Escape POW Camp)">
                          File
                        </span>
                      )}
                      {p.isEliminated && (
                        <span className="text-[10px] bg-red-600 text-white px-1.5 py-0.5 rounded uppercase tracking-wider font-bold">
                          Eliminated
                        </span>
                      )}
                      {!p.isEliminated && p.waitTurns ? (
                        <span className="text-[10px] bg-neutral-600 text-white px-1.5 py-0.5 rounded uppercase tracking-wider font-bold">
                          Wait {p.waitTurns}
                        </span>
                      ) : null}
                    </span>
                  </div>
                  <span className="font-mono text-green-400 font-bold">${p.money}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Marketplace Sidebar / Active Trades */}
          <div className="mt-6 bg-neutral-800 p-6 rounded-xl border border-neutral-700 flex-1 shadow-xl flex flex-col min-h-[250px]">
            <h3 className="text-xl font-bold mb-4 flex items-center justify-between">
              Marketplace
              {activeTrades.filter(t => t.status === 'pending').length > 0 && (
                <span className="text-xs bg-blue-600 px-2 py-1 rounded-full">{activeTrades.filter(t => t.status === 'pending').length} Active</span>
              )}
            </h3>
            
            {activeTrades.filter(t => t.status === 'pending').length === 0 ? (
              <p className="text-sm text-neutral-500 italic text-center my-auto py-8">No active trade offers.</p>
            ) : (
              <div className="flex flex-col gap-3 max-h-96 overflow-y-auto pr-2">
                {activeTrades.filter(t => t.status === 'pending').map(trade => {
                  const sender = players.find(p => p.id === trade.senderId);
                  const receiver = players.find(p => p.id === trade.receiverId);
                  if (!sender || !receiver) return null;
                  
                  const isSender = localUserId === trade.senderId;
                  const isReceiver = localUserId === trade.receiverId;
                  
                  return (
                    <div key={trade.id} className="bg-neutral-900 border border-neutral-600 rounded-lg p-3 text-sm flex flex-col gap-2">
                      <div className="flex justify-between items-center mb-1">
                        <span className="font-bold text-blue-400">{sender.name}'s Offer</span>
                        <span className="text-xs px-2 py-0.5 rounded bg-amber-500/20 text-amber-500">Pending</span>
                      </div>
                      
                      <div className="flex bg-neutral-800 rounded p-2 text-xs">
                        <div className="flex-1 pr-2 border-r border-neutral-700">
                          <span className="text-neutral-500 block mb-1 text-[10px] uppercase">Offering</span>
                          {trade.offeredMoney > 0 && <div className="text-green-400 font-bold">${trade.offeredMoney}</div>}
                          {trade.offeredProperties.length > 0 && <div>{trade.offeredProperties.length} Props</div>}
                          {trade.offeredMoney === 0 && trade.offeredProperties.length === 0 && <div className="text-neutral-600 italic">Nothing</div>}
                        </div>
                        <div className="flex-1 pl-2">
                          <span className="text-neutral-500 block mb-1 text-[10px] uppercase">Requesting ({receiver.name})</span>
                          {trade.requestedMoney > 0 && <div className="text-red-400 font-bold">${trade.requestedMoney}</div>}
                          {trade.requestedProperties.length > 0 && <div>{trade.requestedProperties.length} Props</div>}
                          {trade.requestedMoney === 0 && trade.requestedProperties.length === 0 && <div className="text-neutral-600 italic">Nothing</div>}
                        </div>
                      </div>
                      
                      <div className="mt-2 flex gap-2">
                        {isSender ? (
                          <button 
                            onClick={() => handleTradeResponse(trade.id, 'cancel')}
                            className="flex-1 py-1.5 bg-neutral-700 hover:bg-neutral-600 text-white rounded text-xs font-bold transition-colors"
                          >
                            Cancel Offer
                          </button>
                        ) : isReceiver ? (
                          <>
                            <button 
                              onClick={() => handleTradeResponse(trade.id, 'accept')}
                              className="flex-1 py-1.5 bg-green-600 hover:bg-green-500 text-white rounded text-xs font-bold transition-colors"
                            >
                              Accept
                            </button>
                            <button 
                              onClick={() => handleTradeResponse(trade.id, 'decline')}
                              className="flex-1 py-1.5 bg-red-600 hover:bg-red-500 text-white rounded text-xs font-bold transition-colors"
                            >
                              Decline
                            </button>
                          </>
                        ) : (
                          <div className="flex-1 py-1.5 bg-neutral-800 text-neutral-500 text-center rounded text-xs border border-dashed border-neutral-700">
                            Spectating
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Space Details Modal */}
      {selectedSpace && (
        <div 
          className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4 backdrop-blur-sm"
          onClick={() => setSelectedSpace(null)}
        >
          <div 
            className="bg-neutral-800 p-4 rounded-xl border border-neutral-700 max-w-sm w-full relative shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <button 
              onClick={() => setSelectedSpace(null)} 
              className="absolute top-3 right-3 text-neutral-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
            
            <h2 className="text-xl font-bold mb-3 pr-8">{selectedSpace.name}</h2>
            
            {/* Property Card Image */}
            {['property', 'railroad', 'utility'].includes(selectedSpace.type) && (
              <div className="w-full aspect-[2.5/3.5] max-h-[40vh] bg-neutral-900 rounded-lg mb-4 overflow-hidden relative border border-neutral-700 flex items-center justify-center group">
                <span className="text-neutral-500 absolute z-0 font-medium tracking-widest uppercase text-xs">Loading Card...</span>
                <img 
                  src={`/COD PROPERTY CARDS 2/${selectedSpace.name === 'Advance UAV' ? 'advanced uav' : selectedSpace.name.toLowerCase()}.png`} 
                  alt={selectedSpace.name}
                  className="w-full h-full object-contain relative z-10 transition-opacity duration-300"
                  onError={(e) => {
                    // Fallback if the image fails to load
                    e.currentTarget.style.display = 'none';
                  }}
                />
              </div>
            )}

            <div className="space-y-2 text-sm text-neutral-300 bg-neutral-900/50 p-3 rounded-lg border border-neutral-700/50">
              <div className="flex justify-between items-center">
                <span className="font-semibold text-neutral-400">
                  {selectedSpace.name === 'Capture the Point' ? 'Player Operation' : selectedSpace.name === 'GO!' ? 'Bonus' : 'Type'}
                </span>
                {selectedSpace.name !== 'Capture the Point' && selectedSpace.name !== 'GO!' && (
                  <span className="capitalize font-medium text-white">
                    {selectedSpace.type === 'railroad' ? 'Scorestreak' : selectedSpace.type}
                  </span>
                )}
                {selectedSpace.name === 'GO!' && (
                  <span className="capitalize font-medium text-green-400">Gain $200</span>
                )}
              </div>
              
              {selectedSpace.price && selectedSpace.name !== 'Capture the Point' && selectedSpace.name !== 'GO!' && (
                <>
                  <div className="flex justify-between items-center">
                    <span className="font-semibold text-neutral-400">Price</span>
                    <span className="font-mono text-green-400 font-bold">${selectedSpace.price}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-semibold text-neutral-400">
                      {selectedSpace.type === 'property' ? 'Rent (Tent/Base)' : 'Rent'}
                    </span>
                    <span className="font-mono text-neutral-300">${getRentCost(selectedSpace, 'tent')}</span>
                  </div>
                  {selectedSpace.type === 'property' && (
                    <div className="flex justify-between items-center">
                      <span className="font-semibold text-neutral-400">Rent (HQ)</span>
                      <span className="font-mono text-neutral-300">${getRentCost(selectedSpace, 'hq')}</span>
                    </div>
                  )}
                  <div className="flex justify-between items-center">
                    <span className="font-semibold text-neutral-400">Mortgage Value</span>
                    <span className="font-mono text-neutral-300">${getMortgageValue(selectedSpace)}</span>
                  </div>
                </>
              )}
              
              {selectedSpace.subtitle && (
                <div className="flex justify-between items-center">
                  <span className="font-semibold text-neutral-400">Info</span>
                  <span className="font-medium text-white uppercase text-sm">{selectedSpace.subtitle}</span>
                </div>
              )}
            </div>

            {selectedSpace.price && (
              <div className="mt-4 flex flex-col gap-2">
                {!properties[selectedSpace.id] ? (
                  currentPlayer.position === selectedSpace.id && currentPlayer.id === localUserId ? (
                    <button
                      onClick={() => {
                        if (currentPlayer.money >= selectedSpace.price!) {
                          setPlayers(prev => {
                            const newPlayers = prev.map(p => ({...p}));
                            newPlayers[currentPlayerIndex].money -= selectedSpace.price!;
                            return newPlayers;
                          });
                          setProperties(prev => ({
                            ...prev,
                            [selectedSpace.id]: { ownerId: currentPlayer.id, level: 'tent' }
                          }));
                          setHasActed(true);
                          
                          const kaching = playAudio('/COD MUSIC AND SFX/Cash Register (Kaching) - Sound Effect (HD).mp3');
                          if (selectedSpace.id === 15) {
                            kaching.onended = () => {
                              playAudio('/COD MUSIC AND SFX/auav_on_approach.mp3');
                            };
                          }
                          
                          alert(`You bought ${selectedSpace.name}!`);
                        } else {
                          alert("Not enough money!");
                        }
                      }}
                      disabled={!hasRolled || hasActed || mustPayRent}
                      className={`w-full py-2 ${!hasRolled || hasActed || mustPayRent ? 'bg-neutral-600 text-neutral-400 cursor-not-allowed' : 'bg-green-600 hover:bg-green-500 text-white'} font-bold rounded transition-colors`}
                    >
                      Buy for ${selectedSpace.price}
                    </button>
                  ) : (
                    <div className="p-2 bg-neutral-900 rounded text-center text-neutral-400 border border-neutral-700">
                      Unowned
                    </div>
                  )
                ) : properties[selectedSpace.id].ownerId === currentPlayer.id ? (
                  currentPlayer.position === selectedSpace.id && currentPlayer.id === localUserId ? (
                    <div className="flex flex-col gap-2">
                      {selectedSpace.type === 'property' && properties[selectedSpace.id].level === 'tent' && !properties[selectedSpace.id].isMortgaged && (
                        <button
                          onClick={() => {
                            const upgradeCost = selectedSpace.price!;
                            if (currentPlayer.money >= upgradeCost) {
                              setPlayers(prev => {
                                const newPlayers = prev.map(p => ({...p}));
                                newPlayers[currentPlayerIndex].money -= upgradeCost;
                                return newPlayers;
                              });
                              setProperties(prev => ({
                                ...prev,
                                [selectedSpace.id]: { ...prev[selectedSpace.id], level: 'hq' }
                              }));
                              setHasActed(true);
                              alert(`You upgraded ${selectedSpace.name} to HQ!`);
                            } else {
                              alert("Not enough money!");
                            }
                          }}
                          disabled={!hasRolled || hasActed || mustPayRent}
                          className={`w-full py-2 ${!hasRolled || hasActed || mustPayRent ? 'bg-neutral-600 text-neutral-400 cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-500 text-white'} font-bold rounded transition-colors`}
                        >
                          Upgrade to HQ for ${selectedSpace.price}
                        </button>
                      )}
                      {!properties[selectedSpace.id].isMortgaged ? (
                        <button 
                          onClick={() => {
                            playAudio('/COD MUSIC AND SFX/Resident Evil 4 - Merchant Quotes - Thank You.mp3');
                            const val = getMortgageValue(selectedSpace);
                            setPlayers(prev => {
                              const newPlayers = prev.map(p => ({...p}));
                              newPlayers[currentPlayerIndex].money += val;
                              return newPlayers;
                            });
                            setProperties(prev => ({
                              ...prev,
                              [selectedSpace.id]: { ...prev[selectedSpace.id], isMortgaged: true }
                            }));
                            setHasActed(true);
                            alert(`You mortgaged ${selectedSpace.name} for $${val}!`);
                          }}
                          disabled={!hasRolled || (hasActed && !mustPayRent)}
                          className={`w-full py-2 ${!hasRolled || (hasActed && !mustPayRent) ? 'bg-neutral-600 text-neutral-400 cursor-not-allowed' : 'bg-orange-600 hover:bg-orange-500 text-white'} font-bold rounded transition-colors`}
                        >
                          Mortgage for ${getMortgageValue(selectedSpace)}
                        </button>
                      ) : (
                        <button 
                          onClick={() => {
                            const val = getMortgageValue(selectedSpace) + Math.ceil(getMortgageValue(selectedSpace) * 0.1);
                            if (currentPlayer.money >= val) {
                              setPlayers(prev => {
                                const newPlayers = prev.map(p => ({...p}));
                                newPlayers[currentPlayerIndex].money -= val;
                                return newPlayers;
                              });
                              setProperties(prev => ({
                                ...prev,
                                [selectedSpace.id]: { ...prev[selectedSpace.id], isMortgaged: false }
                              }));
                              setHasActed(true);
                              alert(`You unmortgaged ${selectedSpace.name}!`);
                            } else {
                              alert("Not enough money to unmortgage!");
                            }
                          }}
                          disabled={!hasRolled || hasActed || mustPayRent}
                          className={`w-full py-2 ${!hasRolled || hasActed || mustPayRent ? 'bg-neutral-600 text-neutral-400 cursor-not-allowed' : 'bg-green-600 hover:bg-green-500 text-white'} font-bold rounded transition-colors`}
                        >
                          Unmortgage for ${getMortgageValue(selectedSpace) + Math.ceil(getMortgageValue(selectedSpace) * 0.1)}
                        </button>
                      )}
                    </div>
                  ) : (
                    <div className="p-2 bg-neutral-900 rounded text-center text-neutral-400 border border-neutral-700">
                      {properties[selectedSpace.id].isMortgaged ? 'Mortgaged' : selectedSpace.type === 'property' && properties[selectedSpace.id].level === 'hq' ? 'Fully Upgraded' : 'Owned by You'}
                    </div>
                  )
                ) : (
                  <div className="flex flex-col gap-2">
                    <div className="p-2 bg-neutral-900 rounded text-center text-neutral-400 border border-neutral-700">
                      {properties[selectedSpace.id].isMortgaged ? 'Mortgaged by ' : 'Owned by '}
                      {players.find(p => p.id === properties[selectedSpace.id].ownerId)?.name}
                    </div>
                    {currentPlayer.position === selectedSpace.id && !properties[selectedSpace.id].isMortgaged && (
                      <button
                        onClick={handlePayRent}
                        className="w-full py-2 bg-red-600 hover:bg-red-500 text-white font-bold rounded transition-colors"
                      >
                        Pay Rent ${getRentCost(selectedSpace, properties[selectedSpace.id].level)}
                      </button>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}
      {/* Eliminated Player Alert Modal */}
      {eliminatedPlayerAlert && (
        <div className="fixed inset-0 bg-black/90 z-[150] flex items-center justify-center p-4 backdrop-blur-md">
          <div className="bg-neutral-800 p-8 rounded-xl border-2 border-red-600 max-w-md w-full text-center shadow-2xl animate-in fade-in zoom-in duration-500">
            <h2 className="text-4xl font-black uppercase tracking-widest text-red-500 mb-4">
              ELIMINATED
            </h2>
            <p className="text-xl text-white mb-8">
              {eliminatedPlayerAlert.name}, you have been eliminated from the game!
            </p>
            <div className="flex flex-col gap-4">
              <button
                onClick={() => setEliminatedPlayerAlert(null)}
                className="w-full py-4 bg-neutral-700 hover:bg-neutral-600 text-white font-bold rounded-lg transition-colors"
              >
                Spectate
              </button>
              <button
                onClick={() => {
                  setEliminatedPlayerAlert(null);
                  setCurrentView('main_menu');
                  setGameOver(false);
                }}
                className="w-full py-4 bg-red-600 hover:bg-red-500 text-white font-bold rounded-lg transition-colors"
              >
                Leave Game
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Capture Point Modal */}
      {showCapturePointModal && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
          <div className="bg-neutral-800 p-6 rounded-xl border border-neutral-700 max-w-2xl w-full relative shadow-2xl max-h-[80vh] overflow-y-auto">
            <h2 className="text-2xl font-bold mb-2 text-red-500 flex items-center gap-2">
              <MapPin className="w-6 h-6" /> CAPTURE THE POINT
            </h2>
            <p className="text-neutral-300 mb-6">
              You landed on Capture the Point! You can choose to capture 1 property owned by another player for DOUBLE its original price, or skip.
            </p>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
              {capturableProperties.map(propId => {
                const space = spaces.find(s => s.id === propId);
                const owner = players.find(p => p.id === properties[propId].ownerId);
                if (!space || !owner || !space.price) return null;
                
                const captureCost = space.price * 2;
                const canAfford = currentPlayer.money >= captureCost;

                return (
                  <div key={propId} className="bg-neutral-900 p-4 rounded-lg border border-neutral-700 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        {space.color && <div className={`w-4 h-4 rounded-full ${space.color}`} />}
                        <span className="font-bold">{space.name}</span>
                      </div>
                      <p className="text-sm text-neutral-400 mb-1">Owned by: <span className="text-white">{owner.name}</span></p>
                      <p className="text-sm text-neutral-400">Capture Cost: <span className={`font-mono font-bold ${canAfford ? 'text-red-400' : 'text-neutral-500'}`}>${captureCost}</span></p>
                    </div>
                    <button
                      disabled={!canAfford}
                      onClick={() => {
                        setPlayers(prev => {
                          const newPlayers = prev.map(p => ({...p}));
                          const current = newPlayers[currentPlayerIndex];
                          const previousOwnerIdx = newPlayers.findIndex(p => p.id === owner.id);
                          
                          current.money -= captureCost;
                          if (previousOwnerIdx !== -1) {
                            newPlayers[previousOwnerIdx].money += captureCost;
                          }
                          return newPlayers;
                        });
                        
                        setProperties(prev => ({
                          ...prev,
                          [propId]: {
                            ...prev[propId],
                            ownerId: currentPlayer.id
                          }
                        }));
                        
                        alert(`You captured ${space.name} from ${owner.name} for $${captureCost}!`);
                        setShowCapturePointModal(false);
                        endTurn(currentPlayerIndex);
                      }}
                      className={`mt-4 w-full py-2 rounded font-bold transition-colors ${canAfford ? 'bg-red-600 hover:bg-red-500 text-white' : 'bg-neutral-700 text-neutral-500 cursor-not-allowed'}`}
                    >
                      {canAfford ? 'Capture' : 'Cannot Afford'}
                    </button>
                  </div>
                );
              })}
            </div>

            <button
              onClick={() => {
                setShowCapturePointModal(false);
                endTurn(currentPlayerIndex);
              }}
              className="w-full py-3 bg-neutral-700 hover:bg-neutral-600 text-white font-bold rounded-lg transition-colors"
            >
              Skip Capture
            </button>
          </div>
        </div>
      )}

      {/* Trade Modal - Proposal Composer */}
      {showTradeModal && (
        <div 
          className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4 backdrop-blur-sm"
          onClick={() => setShowTradeModal(false)}
        >
          <div 
            className="bg-neutral-800 p-6 rounded-xl border border-neutral-700 max-w-3xl w-full relative shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <button 
              onClick={() => setShowTradeModal(false)} 
              className="absolute top-4 right-4 text-neutral-400 hover:text-white transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
            
            <h2 className="text-2xl font-bold mb-6">Create Trade Offer</h2>
            
            <div className="flex gap-6">
              {/* Sender (You) Side */}
              <div className="flex-1 bg-neutral-900/50 p-4 rounded-lg border border-neutral-700/50">
                <h3 className="text-lg font-bold text-white mb-4">Your Offer</h3>
                
                <div className="mb-4">
                  <label className="block text-sm text-neutral-400 mb-1">Offer Money</label>
                  <button
                    onClick={() => setActiveKeypad('player1')}
                    className="w-full bg-neutral-800 border border-neutral-600 rounded p-2 text-white text-left"
                  >
                    ${tradeState.offeredMoney}
                  </button>
                  <span className="text-xs text-neutral-500">Max: ${players.find(p => p.id === localUserId)?.money || 0}</span>
                </div>
                
                <div>
                  <label className="block text-sm text-neutral-400 mb-1">Offer Properties</label>
                  <div className="flex flex-col gap-2 max-h-40 overflow-y-auto">
                    {Object.entries(properties).filter(([_, prop]) => prop.ownerId === localUserId).map(([spaceId, prop]) => {
                      const space = spaces.find(s => s.id === Number(spaceId));
                      if (!space) return null;
                      return (
                        <label key={spaceId} className="flex items-center gap-2 p-2 bg-neutral-800 rounded border border-neutral-700 cursor-pointer hover:bg-neutral-700">
                          <input 
                            type="checkbox"
                            checked={tradeState.offeredProperties.includes(Number(spaceId))}
                            onChange={(e) => {
                              if (e.target.checked) setTradeState(prev => ({ ...prev, offeredProperties: [...prev.offeredProperties, Number(spaceId)] }));
                              else setTradeState(prev => ({ ...prev, offeredProperties: prev.offeredProperties.filter(id => id !== Number(spaceId)) }));
                            }}
                          />
                          <span>{space.name} ({prop.level})</span>
                        </label>
                      );
                    })}
                    {Object.entries(properties).filter(([_, prop]) => prop.ownerId === localUserId).length === 0 && (
                      <span className="text-sm text-neutral-500 italic">No properties owned.</span>
                    )}
                  </div>
                </div>
              </div>

              {/* Receiver (Target Player) Side */}
              <div className="flex-1 bg-neutral-900/50 p-4 rounded-lg border border-neutral-700/50">
                <select 
                  className="w-full bg-neutral-800 border border-neutral-600 rounded p-2 mb-4 text-white font-bold"
                  value={tradeState.targetPlayerId}
                  onChange={(e) => setTradeState(prev => ({ ...prev, targetPlayerId: Number(e.target.value), requestedProperties: [] }))}
                >
                  {players.filter(p => !p.isEliminated && p.id !== localUserId).map(p => (
                    <option key={p.id} value={p.id}>Request from {p.name}</option>
                  ))}
                </select>
                
                <div className="mb-4">
                  <label className="block text-sm text-neutral-400 mb-1">Request Money</label>
                  <button
                    onClick={() => setActiveKeypad('player2')}
                    className="w-full bg-neutral-800 border border-neutral-600 rounded p-2 text-white text-left"
                  >
                    ${tradeState.requestedMoney}
                  </button>
                  <span className="text-xs text-neutral-500">Max: ${players.find(p => p.id === tradeState.targetPlayerId)?.money || 0}</span>
                </div>
                
                <div>
                  <label className="block text-sm text-neutral-400 mb-1">Request Properties</label>
                  <div className="flex flex-col gap-2 max-h-40 overflow-y-auto">
                    {Object.entries(properties).filter(([_, prop]) => prop.ownerId === tradeState.targetPlayerId).map(([spaceId, prop]) => {
                      const space = spaces.find(s => s.id === Number(spaceId));
                      if (!space) return null;
                      return (
                        <label key={spaceId} className="flex items-center gap-2 p-2 bg-neutral-800 rounded border border-neutral-700 cursor-pointer hover:bg-neutral-700">
                          <input 
                            type="checkbox"
                            checked={tradeState.requestedProperties.includes(Number(spaceId))}
                            onChange={(e) => {
                              if (e.target.checked) setTradeState(prev => ({ ...prev, requestedProperties: [...prev.requestedProperties, Number(spaceId)] }));
                              else setTradeState(prev => ({ ...prev, requestedProperties: prev.requestedProperties.filter(id => id !== Number(spaceId)) }));
                            }}
                          />
                          <span>{space.name} ({prop.level})</span>
                        </label>
                      );
                    })}
                    {Object.entries(properties).filter(([_, prop]) => prop.ownerId === tradeState.targetPlayerId).length === 0 && (
                      <span className="text-sm text-neutral-500 italic">No properties owned.</span>
                    )}
                  </div>
                </div>
              </div>
            </div>
            
            <button
              onClick={() => {
                if (tradeState.offeredMoney === 0 && tradeState.requestedMoney === 0 && tradeState.offeredProperties.length === 0 && tradeState.requestedProperties.length === 0) {
                  alert("Cannot send an empty trade offer!");
                  return;
                }
                const newTrade = {
                  id: Math.random().toString(36).substring(2, 9),
                  senderId: localUserId,
                  receiverId: tradeState.targetPlayerId,
                  offeredMoney: tradeState.offeredMoney,
                  requestedMoney: tradeState.requestedMoney,
                  offeredProperties: [...tradeState.offeredProperties],
                  requestedProperties: [...tradeState.requestedProperties],
                  senderConfirmed: true,
                  receiverConfirmed: false,
                  status: 'pending'
                };
                setActiveTrades(prev => [...prev, newTrade]);
                setShowTradeModal(false);
                setTradeState({
                  targetPlayerId: players.find(p => p.id !== localUserId && !p.isEliminated)?.id || 2,
                  offeredMoney: 0,
                  requestedMoney: 0,
                  offeredProperties: [],
                  requestedProperties: []
                });
              }}
              className="w-full mt-6 py-3 font-bold rounded-lg transition-colors bg-blue-600 hover:bg-blue-500 text-white"
            >
              Send Trade Offer
            </button>
          </div>
        </div>
      )}

      {activeKeypad && (
        <NumericalKeypad
          value={activeKeypad === 'player1' ? tradeState.offeredMoney : tradeState.requestedMoney}
          max={players.find(p => p.id === (activeKeypad === 'player1' ? localUserId : tradeState.targetPlayerId))?.money || 0}
          onChange={(val) => {
            if (activeKeypad === 'player1') {
              setTradeState(prev => ({ ...prev, offeredMoney: val }));
            } else {
              setTradeState(prev => ({ ...prev, requestedMoney: val }));
            }
          }}
          onClose={() => setActiveKeypad(null)}
        />
      )}


      {gameOver && (
        <div className="fixed inset-0 bg-black/90 z-[100] flex items-center justify-center p-4 backdrop-blur-md">
          <div className="bg-neutral-800 p-8 rounded-xl border-2 border-neutral-600 max-w-2xl w-full text-center shadow-2xl animate-in fade-in zoom-in duration-500">
            <h1 className="text-5xl font-black uppercase tracking-widest text-yellow-500 mb-8">
              Mission Accomplished
            </h1>
            
            <div className="mb-8">
              <h2 className="text-2xl text-neutral-400 mb-2">Winner</h2>
              <div className="text-4xl font-bold text-white">
                {players.find(p => !p.isEliminated)?.name || 'No One'}
              </div>
            </div>

            <div className="mb-12">
              <h2 className="text-xl text-neutral-400 mb-4">Eliminated</h2>
              <div className="flex flex-wrap justify-center gap-4">
                {players.filter(p => p.isEliminated).map(p => (
                  <div key={p.id} className="bg-neutral-900 px-4 py-2 rounded-lg border border-neutral-700 text-neutral-500 line-through">
                    {p.name}
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-neutral-900/50 p-6 rounded-lg border border-neutral-700">
              <h3 className="text-xl font-bold mb-4">Restart Game? ({restartTimer}s)</h3>
              <p className="text-neutral-400 mb-6">All players must agree to restart.</p>
              
              <div className="flex flex-wrap justify-center gap-4 mb-6">
                {players.map(p => (
                  <button
                    key={p.id}
                    onClick={() => {
                      if (!restartVotes.includes(p.id)) {
                        setRestartVotes(prev => [...prev, p.id]);
                      }
                    }}
                    disabled={restartVotes.includes(p.id)}
                    className={`px-6 py-3 rounded-lg font-bold transition-all ${
                      restartVotes.includes(p.id) 
                        ? 'bg-green-600 text-white cursor-not-allowed' 
                        : 'bg-neutral-700 hover:bg-neutral-600 text-white'
                    }`}
                  >
                    {p.name} {restartVotes.includes(p.id) ? '✓' : '?'}
                  </button>
                ))}
              </div>
              
              <div className="w-full bg-neutral-800 rounded-full h-2 overflow-hidden">
                <div 
                  className="bg-blue-500 h-full transition-all duration-1000 ease-linear"
                  style={{ width: `${(restartTimer / 20) * 100}%` }}
                />
              </div>
            </div>
          </div>
        </div>
      )}
        </>
      )}

      {/* Settings Overlay */}
      {showSettings && (
        <div className="fixed inset-0 bg-black/90 z-[100] flex items-center justify-center p-4 backdrop-blur-md">
          <div className="bg-neutral-800 p-8 rounded-xl border-2 border-neutral-600 max-w-md w-full shadow-2xl flex flex-col gap-6 max-h-[90vh] overflow-y-auto">
            <h2 className="text-3xl font-black uppercase tracking-widest text-white mb-2 text-center">Settings</h2>
            
            <div>
              <label className="block text-sm text-neutral-400 mb-2">Screen Options</label>
              <div className="flex gap-2">
                <button
                  onClick={() => {
                    if (!document.fullscreenElement) {
                      document.documentElement.requestFullscreen().catch(e => console.log(e));
                      setIsFullscreen(true);
                    }
                  }}
                  className={`flex-1 py-2 rounded font-bold ${isFullscreen ? 'bg-blue-600 text-white' : 'bg-neutral-700 text-neutral-300 hover:bg-neutral-600'}`}
                >
                  Full Screen
                </button>
                <button
                  onClick={() => {
                    if (document.fullscreenElement) {
                      document.exitFullscreen().catch(e => console.log(e));
                      setIsFullscreen(false);
                    }
                  }}
                  className={`flex-1 py-2 rounded font-bold ${!isFullscreen ? 'bg-blue-600 text-white' : 'bg-neutral-700 text-neutral-300 hover:bg-neutral-600'}`}
                >
                  Windowed
                </button>
              </div>
            </div>

            <div>
              <div className="flex justify-between mb-2">
                <label className="text-sm text-neutral-400">Music</label>
                <button 
                  onClick={() => setMusicEnabled(!musicEnabled)}
                  className={`text-xs px-2 py-1 rounded font-bold ${musicEnabled ? 'bg-green-600 text-white' : 'bg-red-600 text-white'}`}
                >
                  {musicEnabled ? 'Enabled' : 'Disabled'}
                </button>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.01"
                value={musicVolume}
                onChange={(e) => setMusicVolume(parseFloat(e.target.value))}
                disabled={!musicEnabled}
                className={`w-full accent-blue-500 ${!musicEnabled ? 'opacity-50 cursor-not-allowed' : ''}`}
              />
            </div>

            <div>
              <div className="flex justify-between mb-2">
                <label className="text-sm text-neutral-400">In-game Sounds</label>
                <button 
                  onClick={() => setSfxEnabled(!sfxEnabled)}
                  className={`text-xs px-2 py-1 rounded font-bold ${sfxEnabled ? 'bg-green-600 text-white' : 'bg-red-600 text-white'}`}
                >
                  {sfxEnabled ? 'Enabled' : 'Disabled'}
                </button>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.01"
                value={sfxVolume}
                onChange={(e) => setSfxVolume(parseFloat(e.target.value))}
                disabled={!sfxEnabled}
                className={`w-full accent-blue-500 ${!sfxEnabled ? 'opacity-50 cursor-not-allowed' : ''}`}
              />
            </div>

            <div>
              <label className="block text-sm text-neutral-400 mb-2">Time Per Turn</label>
              <select
                value={turnDuration}
                onChange={(e) => setTurnDuration(Number(e.target.value))}
                className="w-full bg-neutral-700 border border-neutral-600 rounded p-2 text-white"
              >
                <option value={20}>20 Seconds</option>
                <option value={30}>30 Seconds</option>
                <option value={60}>1 Minute</option>
                <option value={90}>1 Minute and 30 Seconds</option>
                <option value={120}>2 Minutes</option>
              </select>
            </div>

            <div>
              <label className="block text-sm text-neutral-400 mb-2">Brightness</label>
              <input
                type="range"
                min="0.2"
                max="2"
                step="0.1"
                value={brightness}
                onChange={(e) => setBrightness(Number(e.target.value))}
                className="w-full accent-blue-500"
              />
            </div>
            
            <button
              onClick={() => {
                setShowSettings(false);
                if (currentView === 'game') {
                  setShowMenu(true);
                }
              }}
              className="w-full py-3 bg-neutral-600 hover:bg-neutral-500 text-white font-bold rounded-lg transition-colors mt-4"
            >
              Back
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
