import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { getAuth } from "firebase/auth";
import { getDatabase } from "firebase/database";

const firebaseConfig = {
  apiKey: "AIzaSyCpno-hYT8YWU45HMI8h1giwjkk0H5DsEo",
  authDomain: "call-of-duty-monopoly.firebaseapp.com",
  projectId: "call-of-duty-monopoly",
  storageBucket: "call-of-duty-monopoly.firebasestorage.app",
  messagingSenderId: "301530794753",
  appId: "1:301530794753:web:b212eb37e960832a186900",
  measurementId: "G-21V43FYFZQ",
  databaseURL: "https://call-of-duty-monopoly-default-rtdb.asia-southeast1.firebasedatabase.app"
};

export const app = initializeApp(firebaseConfig);
export const analytics = getAnalytics(app);
export const auth = getAuth(app);
export const db = getDatabase(app, "https://call-of-duty-monopoly-default-rtdb.asia-southeast1.firebasedatabase.app");
